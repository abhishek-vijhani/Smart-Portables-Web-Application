
import java.sql.*;
import java.io.*;
import java.text.*;
import java.util.*;


public class MySqlDataStoreUtilities
{
	User u =null;
   public static Connection conn = null;
  public static void getConnection()
  {
    try
   {
      Class.forName("com.mysql.jdbc.Driver").newInstance();
      conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/smartportables?useSSL=false","root","abhishek");
	   System.out.println("got connection");
   }
   catch(Exception e)
  {}
}
  public static void deletetable()
  {
	  try{
	 getConnection();
      String deleteTableQuery = "DROP TABLE IF EXISTS product1;";
      PreparedStatement pst =
      conn.prepareStatement(deleteTableQuery); 
	  pst.execute();
	  
	  }
	  catch(Exception e){System.out.println(e);}
	  
  }
  
    public static void createtable()
  {
	  try{
	 getConnection();
      String deleteTableQuery = "CREATE TABLE product1 (product_category varchar(40),product_id int(3),product_name varchar(40),retailer varchar(40),product_condition varchar (40),price int(11),sale varchar(40), rebate varchar(40), quantity int(11));";
      PreparedStatement pst =
      conn.prepareStatement(deleteTableQuery); 
	  pst.execute();
	  
	  }
	  catch(Exception e){System.out.println(e);}
	  
  }
  
  public static void insertProductLaptop(HashMap<String,LaptopsTest> insproduct)
  {
    try{
	   System.out.println("Attempt for connection");
      getConnection();
	  Iterator<Map.Entry<String,LaptopsTest>> itr = insproduct.entrySet().iterator() ;
        while(itr.hasNext()){
            Map.Entry<String,LaptopsTest> inspro = itr.next();
			LaptopsTest lap = inspro.getValue();
	  
      String insertIntoProduct = "INSERT INTO product1(product_category,product_id,product_name,retailer,product_condition,price,sale,rebate,quantity) "
         + "VALUES (?,?,?,?,?,?,?,?,?);";
      PreparedStatement pst =
      conn.prepareStatement(insertIntoProduct);
       pst.setString(1,lap.getProducttype());
       pst.setString(2,lap.getId());
	   pst.setString(3,lap.getName());
       pst.setString(4,lap.getRetailer());
	   pst.setString(5,lap.getCondition());
	   pst.setInt(6,lap.getPrice());
	   pst.setString(7,lap.getSale());
	   pst.setString(8,lap.getRebate());
	   pst.setInt(9,lap.getQuantity());
       pst.execute();
	  }
	   System.out.println("Data inserted");
}
catch(Exception e){System.out.println(e);}
}


public static void insertProductES(HashMap<String,ESTest> insproduct)
  {
    try{
	   System.out.println("Attempt for connection");
      getConnection();
	  Iterator<Map.Entry<String,ESTest>> itr = insproduct.entrySet().iterator() ;
        while(itr.hasNext()){
            Map.Entry<String,ESTest> inspro = itr.next();
			ESTest lap = inspro.getValue();
	  
      String insertIntoProduct = "INSERT INTO product1(product_category,product_id,product_name,retailer,product_condition,price,sale,rebate,quantity) "
         + "VALUES (?,?,?,?,?,?,?,?,?);";
      PreparedStatement pst =
      conn.prepareStatement(insertIntoProduct);
       pst.setString(1,lap.getProducttype());
       pst.setString(2,lap.getId());
	   pst.setString(3,lap.getName());
       pst.setString(4,lap.getRetailer());
	   pst.setString(5,lap.getCondition());
	   pst.setInt(6,lap.getPrice());
	   pst.setString(7,lap.getSale());
	   pst.setString(8,lap.getRebate());
	   pst.setInt(9,lap.getQuantity());
       pst.execute();
	  }
	   System.out.println("Data inserted");
}
catch(Exception e){System.out.println(e);}
}

public static void insertProductHeadphones(HashMap<String,HeadphoneTest> insproduct)
  {
    try{
	   System.out.println("Attempt for connection");
      getConnection();
	  Iterator<Map.Entry<String,HeadphoneTest>> itr = insproduct.entrySet().iterator() ;
        while(itr.hasNext()){
            Map.Entry<String,HeadphoneTest> inspro = itr.next();
			HeadphoneTest lap = inspro.getValue();
	  
      String insertIntoProduct = "INSERT INTO product1(product_category,product_id,product_name,retailer,product_condition,price,sale,rebate,quantity) "
         + "VALUES (?,?,?,?,?,?,?,?,?);";
      PreparedStatement pst =
      conn.prepareStatement(insertIntoProduct);
       pst.setString(1,lap.getProducttype());
       pst.setString(2,lap.getId());
	   pst.setString(3,lap.getName());
       pst.setString(4,lap.getRetailer());
	   pst.setString(5,lap.getCondition());
	   pst.setInt(6,lap.getPrice());
	   pst.setString(7,lap.getSale());
	   pst.setString(8,lap.getRebate());
	   pst.setInt(9,lap.getQuantity());
       pst.execute();
	  }
	   System.out.println("Data inserted");
}
catch(Exception e){System.out.println(e);}
}

public static void insertProductPhones(HashMap<String,PhonesTest> insproduct)
  {
    try{
	   System.out.println("Attempt for connection");
      getConnection();
	  Iterator<Map.Entry<String,PhonesTest>> itr = insproduct.entrySet().iterator() ;
        while(itr.hasNext()){
            Map.Entry<String,PhonesTest> inspro = itr.next();
			PhonesTest lap = inspro.getValue();
	  
      String insertIntoProduct = "INSERT INTO product1(product_category,product_id,product_name,retailer,product_condition,price,sale,rebate,quantity) "
         + "VALUES (?,?,?,?,?,?,?,?,?);";
      PreparedStatement pst =
      conn.prepareStatement(insertIntoProduct);
       pst.setString(1,lap.getProducttype());
       pst.setString(2,lap.getId());
	   pst.setString(3,lap.getName());
       pst.setString(4,lap.getRetailer());
	   pst.setString(5,lap.getCondition());
	   pst.setInt(6,lap.getPrice());
	   pst.setString(7,lap.getSale());
	   pst.setString(8,lap.getRebate());
	   pst.setInt(9,lap.getQuantity());
       pst.execute();
	  }
	   System.out.println("Data inserted");
}
catch(Exception e){System.out.println(e);}
}

public static void insertProductSmartwatches(HashMap<String,SmartwatchesTest> insproduct)
  {
    try{
	   System.out.println("Attempt for connection");
      getConnection();
	  Iterator<Map.Entry<String,SmartwatchesTest>> itr = insproduct.entrySet().iterator() ;
        while(itr.hasNext()){
            Map.Entry<String,SmartwatchesTest> inspro = itr.next();
			SmartwatchesTest lap = inspro.getValue();
	  
      String insertIntoProduct = "INSERT INTO product1(product_category,product_id,product_name,retailer,product_condition,price,sale,rebate,quantity) "
         + "VALUES (?,?,?,?,?,?,?,?,?);";
      PreparedStatement pst =
      conn.prepareStatement(insertIntoProduct);
       pst.setString(1,lap.getProducttype());
       pst.setString(2,lap.getId());
	   pst.setString(3,lap.getName());
       pst.setString(4,lap.getRetailer());
	   pst.setString(5,lap.getCondition());
	   pst.setInt(6,lap.getPrice());
	   pst.setString(7,lap.getSale());
	   pst.setString(8,lap.getRebate());
	   pst.setInt(9,lap.getQuantity());
       pst.execute();
	  }
	   System.out.println("Data inserted");
}
catch(Exception e){System.out.println(e);}
}



public static void insertProductSpeakers(HashMap<String,SpeakersTest> insproduct)
  {
    try{
	   System.out.println("Attempt for connection");
      getConnection();
	  Iterator<Map.Entry<String,SpeakersTest>> itr = insproduct.entrySet().iterator() ;
        while(itr.hasNext()){
            Map.Entry<String,SpeakersTest> inspro = itr.next();
			SpeakersTest lap = inspro.getValue();
	  
      String insertIntoProduct = "INSERT INTO product1(product_category,product_id,product_name,retailer,product_condition,price,sale,rebate,quantity) "
         + "VALUES (?,?,?,?,?,?,?,?,?);";
      PreparedStatement pst =
      conn.prepareStatement(insertIntoProduct);
       pst.setString(1,lap.getProducttype());
       pst.setString(2,lap.getId());
	   pst.setString(3,lap.getName());
       pst.setString(4,lap.getRetailer());
	   pst.setString(5,lap.getCondition());
	   pst.setInt(6,lap.getPrice());
	   pst.setString(7,lap.getSale());
	   pst.setString(8,lap.getRebate());
	   pst.setInt(9,lap.getQuantity());
       pst.execute();
	  }
	   System.out.println("Data inserted");
}
catch(Exception e){System.out.println(e);}
}


public static void insertProductAccessories(HashMap<String,AccessoryTest> insproduct)
  {
    try{
	   System.out.println("Attempt for connection");
      getConnection();
	  Iterator<Map.Entry<String,AccessoryTest>> itr = insproduct.entrySet().iterator() ;
        while(itr.hasNext()){
            Map.Entry<String,AccessoryTest> inspro = itr.next();
			AccessoryTest lap = inspro.getValue();
	  
      String insertIntoProduct = "INSERT INTO product1(product_category,product_id,product_name,retailer,product_condition,price,sale,rebate,quantity) "
         + "VALUES (?,?,?,?,?,?,?,?,?);";
      PreparedStatement pst =
      conn.prepareStatement(insertIntoProduct);
       pst.setString(1,lap.getProducttype());
       pst.setString(2,lap.getId());
	   pst.setString(3,lap.getName());
       pst.setString(4,lap.getRetailer());
	   pst.setString(5,lap.getCondition());
	   pst.setInt(6,lap.getPrice());
	   pst.setString(7,lap.getSale());
	   pst.setString(8,lap.getRebate());
	   pst.setInt(9,lap.getQuantity());
       pst.execute();
	  }
	   System.out.println("Data inserted");
}
catch(Exception e){System.out.println(e);}
}


 public static void reduceQuantity(String productid)
  {
	  try{
	 getConnection();
	 
      String deleteTableQuery = "Update product1 set quantity = quantity-1 where product_id ="+productid;
      PreparedStatement pst =
      conn.prepareStatement(deleteTableQuery); 
	  pst.execute();
	  
	  }
	  catch(Exception e){System.out.println(e);}
	  
  }



public static HashMap<String,String> salesreport3(){
	  HashMap <String,String> salesreport3 = new HashMap<String,String> ();
	 
  try{
	  
      getConnection();
      
	  String selectfromproduct = "Select sum(price) as sales, orderdate from orderdetail group by orderdate;";
        
      PreparedStatement pst =
      conn.prepareStatement(selectfromproduct);
	  ResultSet rs = pst.executeQuery();
	  while(rs.next())
	  {
		 String sales = rs.getString("sales");
		 String orderdate = rs.getString("orderdate");
		 salesreport3.put(orderdate,sales);
	  }
	  
}
catch(Exception e){System.out.println(e);}
 return salesreport3;
}

public static HashMap<String,String> salesreport2(){
	  HashMap <String,String> salesreport2 = new HashMap<String,String> ();
	 
  try{
	  
      getConnection();
      
	  String selectfromproduct = "Select sum(price) as totalsales, productname from orderdetail group by productname;";
        
      PreparedStatement pst =
      conn.prepareStatement(selectfromproduct);
	  ResultSet rs = pst.executeQuery();
	  while(rs.next())
	  {
		 String totalsales = rs.getString("totalsales");
		 String productname = rs.getString("productname");
		 salesreport2.put(totalsales,productname);
	  }
	  
}
catch(Exception e){System.out.println(e);}
 return salesreport2;
}


public static HashMap<String,SalesBean> salesreport1(){
	  HashMap <String,SalesBean> salesreport1 = new HashMap<String,SalesBean> ();
	 
  try{
	  
      getConnection();
      
	  String selectfromproduct = "Select sum(price) as totalsales, count(productname) as totalnumber, price as price, productname from orderdetail group by productname;";
        
      PreparedStatement pst =
      conn.prepareStatement(selectfromproduct);
	  ResultSet rs = pst.executeQuery();
	  while(rs.next())
	  {
		String totalsales = rs.getString("totalsales");
		 String productname = rs.getString("productname");
		 int price = rs.getInt("price");
		int totalnumber = rs.getInt("totalnumber");
		 SalesBean salesbean = new SalesBean(totalsales,productname,price,totalnumber);
		 salesreport1.put(productname,salesbean);	
	  }
	  
}
catch(Exception e){System.out.println(e);}
 return salesreport1;
}











































  public static void insertUser(String userName,String passWord,String role){
  try{
	   System.out.println("Attempt for connection");
      getConnection();
      String insertIntoCustomerRegisterQuery = "INSERT INTO USER(userName,passWord,role) "
         + "VALUES (?,?,?);";
      PreparedStatement pst =
      conn.prepareStatement(insertIntoCustomerRegisterQuery);
       pst.setString(1,userName);
       pst.setString(2,passWord);
       pst.setString(3,role);
       pst.execute();
	   System.out.println(userName);
}
catch(Exception e){System.out.println(e);}
}
  
  public static HashMap<String,User> selectUser(){
	  HashMap<String,User> userdata = new HashMap<String,User> ();
  try{
	  
      getConnection();
      
	  String selectIntoCustomerRegisterQuery = "SELECT * FROM USER;";
        
      PreparedStatement pst =
      conn.prepareStatement(selectIntoCustomerRegisterQuery);
	  ResultSet rs = pst.executeQuery();
	  while(rs.next())
	  {
		 String userName = rs.getString("userName");
		 String passWord = rs.getString("passWord");
		 String role = rs.getString("role");
		 User user = new User(userName,passWord,role);
		 userdata.put(userName,user);
	  }
	  
}
catch(Exception e){System.out.println(e);}
 return userdata;
}

  public static ArrayList selectProduct(String maker){
	  ArrayList<Product> prods = new ArrayList<Product> ();
  try{
	  
      getConnection();
      
	  String selectfromproduct = "SELECT * FROM product1 where product_category = ?;";
        
      PreparedStatement pst =
      conn.prepareStatement(selectfromproduct);
	  pst.setString(1,maker);
	  ResultSet rs = pst.executeQuery();
	  while(rs.next())
	  {
		 String producttype = rs.getString("product_category");
		 int productid = rs.getInt("product_id");
		 String productname = rs.getString("product_name");
		 String retailer= rs.getString("retailer");
		 String condition = rs.getString("product_condition");
		 Double price = rs.getDouble("price");
		 String rebate = rs.getString("rebate");
		String sale = rs.getString("sale");
		int quantity = rs.getInt("quantity");
		 Product product = new Product(productname,productid,producttype,retailer,condition,price,sale,rebate,quantity);
		 prods.add(product);
	  }
	  
}
catch(Exception e){System.out.println(e);}
 return prods;
}



  public static HashMap<String,Product> AllProduct(){
	  HashMap <String,Product> allproduct = new HashMap<String,Product> ();
	 
  try{
	  
      getConnection();
      
	  String selectfromproduct = "SELECT * FROM product1 ;";
        
      PreparedStatement pst =
      conn.prepareStatement(selectfromproduct);
	  ResultSet rs = pst.executeQuery();
	  while(rs.next())
	  {
		 String producttype = rs.getString("product_category");
		 int productid = rs.getInt("product_id");
		 String productname = rs.getString("product_name");
		 String retailer= rs.getString("retailer");
		 String condition = rs.getString("product_condition");
		 Double price = rs.getDouble("price");
		 String rebate = rs.getString("rebate");
		String sale = rs.getString("sale");
		int quantity = rs.getInt("quantity");
		 Product product = new Product(productname,productid,producttype,retailer,condition,price,sale,rebate,quantity);
		 allproduct.put(productname,product);
		
	  }
	  
}
catch(Exception e){System.out.println(e);}
 return allproduct;
}






  public static Product selectexactProduct(int productid){
	  Product product = new Product();
  try{
	  
      getConnection();
      
	  String selectfromproduct = "SELECT * FROM product1 where product_id = ?;";
        
      PreparedStatement pst =
      conn.prepareStatement(selectfromproduct);
	  pst.setInt(1,productid);
	 ResultSet rs = pst.executeQuery();
	  while(rs.next())
	  {
		 String producttype = rs.getString("product_category");
	//	 int productid = rs.getInt("product_id");
		 String productname = rs.getString("product_name");
		 String retailer= rs.getString("retailer");
		 String condition = rs.getString("product_condition");
		 Double price = rs.getDouble("price");
		 String rebate = rs.getString("rebate");
		String sale = rs.getString("sale");
		int quantity = rs.getInt("quantity");
		 product = new Product(productname,productid,producttype,retailer,condition,price,sale,rebate,quantity);
	
	  }
	  
}
catch(Exception e){System.out.println(e);}
 return product;
}


  public static void insertOrder(int ordernumber,String username,String orderdate,String deliverydate,String productid,String productname,Double price){
  try{
	   System.out.println("Attempt for connection");
      getConnection();
      String insertIntoCustomerOrder = "INSERT INTO ORDERDETAIL(ordernumber,username,orderdate,deliverydate,productid,productname,price) "
         + "VALUES (?,?,?,?,?,?,?);";
      PreparedStatement pst =
      conn.prepareStatement(insertIntoCustomerOrder);
       pst.setInt(1,ordernumber);
       pst.setString(2,username);
	   pst.setString(3,orderdate);
       pst.setString(4,deliverydate);
	   pst.setString(5,productid);
	   pst.setString(6,productname);
	   pst.setDouble(7,price);
       pst.execute();
	   System.out.println(username);
}
catch(Exception e){System.out.println(e);}
}

  public static HashMap <Integer ,Order >  viewOrder(){
	  HashMap <Integer ,Order > ordercheck = new HashMap <Integer ,Order > ();
  try{
	  
      getConnection();
      
	  String selectIntoOrder = "SELECT * FROM orderdetail;";
        
      PreparedStatement pst =
      conn.prepareStatement(selectIntoOrder);
	  ResultSet rs = pst.executeQuery();
	  while(rs.next())
	  {
		 int ordernumber = rs.getInt("ordernumber");
		 String username = rs.getString("username");
		 String orderdate = rs.getString("orderdate");
		 String deliverydate = rs.getString("deliverydate");
		 String productid = rs.getString("productid");
		 String productname = rs.getString("productname");
		 Double price = rs.getDouble("price");
		 
         Order order = new Order(username,ordernumber,orderdate,deliverydate,productid,productname,price);
		 ordercheck.put(ordernumber,order);
	  }
	  
}
catch(Exception e){System.out.println(e);}
 return ordercheck;
}



  public static  String cancelOrder(int ordernumber){
	    try{
	  
      getConnection();
      
	  String deletefromOrder = "DELETE FROM orderdetail WHERE ordernumber = ?;";
	  
        
      PreparedStatement pst =
      conn.prepareStatement(deletefromOrder);
	  pst.setInt(1,ordernumber);
	  pst.execute();
	  System.out.println("order deleted");
	  return "yes";

	  
}
catch(Exception e){System.out.println(e);}
 return "no";
}


  public static void insertProduct(String producttype,int productid,String retailer,String productname,String condition,Double price){
  try{
	   System.out.println("Attempt for Connection");
      getConnection();
      String insertIntoProduct = "INSERT INTO product1(product_category,product_id,product_name,retailer,product_condition,price) "
         + "VALUES (?,?,?,?,?,?);";
      PreparedStatement pst =
      conn.prepareStatement(insertIntoProduct);
       pst.setString(1,producttype);
       pst.setInt(2,productid);
	   pst.setString(3,retailer);
       pst.setString(4,productname);
	   pst.setString(5,condition);
	   pst.setDouble(6,price);
       pst.execute();
	   
}
catch(Exception e){System.out.println(e);}
}

  public static String updateProduct(String producttype,int productid,String retailer,String productname,String condition,Double price){
  try{
	   System.out.println("Attempt for connection");
      getConnection();
      String upadteProduct = "update product1 set price = ? where product_id = ?";
         
      PreparedStatement pst =
      conn.prepareStatement(upadteProduct);
//       pst.setString(1,retailer);
//       pst.setString(2,condition);
	   pst.setDouble(1,price);
       pst.setInt(2,productid);
	   pst.execute();
	   return "yes";
	   
}
catch(Exception e){System.out.println(e);return "no";}
} 
  public static String deleteProduct(int productid){
  try{
	   System.out.println("Attempt for connection");
      getConnection();
      String deleteProduct = "delete from product1 where product_id = ?";
         
      PreparedStatement pst =
      conn.prepareStatement(deleteProduct);
       pst.setInt(1,productid);
	   pst.execute();
	   System.out.println("product deleted");
	   return "yes";
	   
}
catch(Exception e){System.out.println(e);return "no";}
}
}