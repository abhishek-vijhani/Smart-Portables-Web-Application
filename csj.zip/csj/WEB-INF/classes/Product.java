
import java.util.ArrayList;
import java.util.List;

public class Product {

    String retailer;
    String name;
    int id;
    String condition;
    Double price;
	String producttype;
	String rebate;
	String sale;
	int quantity;
    
	
	public Product()
	{}

    public Product(String name,int id,String producttype,String retailer,String condition,Double price,String sale,String rebate,int quantity){
        this.name = name;
		this.id = id;
		this.producttype = producttype;
		this.retailer = retailer;
		this.condition = condition;
		this.price = price;
		this.sale = sale;
		this.rebate = rebate;
		this.quantity = quantity;
    }

	public String getRetailer() {
		return retailer;
	}



	public String getName() {
		return name;
	}


	public int getId() {
		return id;
	}


	public String getCondition() {
		return condition;
	}


	public String getProducttype() {
		return producttype;
	}

	
	public Double getPrice() {
		return price;
	}
	
	void setQuantity(int quantity) {
	this.quantity = quantity;
}

int getQuantity() {
	return quantity;
}

void setRebate(String rebate) {
	this.rebate = rebate;
}

String getRebate() {
	return rebate;
}

void setSale(String sale) {
	this.sale = sale;
}

String getSale() {
	return sale;
}

   
	
}