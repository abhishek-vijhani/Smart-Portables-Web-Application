import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.HashMap;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginServlet extends HttpServlet implements Serializable {
	
	
	 protected HashMap <String ,User > login = new HashMap<String , User > ();
	

	String username = "";
	String password = "";
	String logintype = "";
	String message = "";
	
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, java.io.IOException 
	{
		
		login = MySqlDataStoreUtilities.selectUser();
        
		
		username = request.getParameter("username");
		password = request.getParameter("password");
		logintype = request.getParameter("role");
		
		
		if(username != null && username.length() != 0) {
            username = username.trim();
        }
        if(password != null && password.length() != 0) {
            password = password.trim();
        }
		
        if(username != null &&
            password != null) {
			if(login.containsKey(username)){
				
			 User user1 = (User)login.get(username);
			 String passcomp = user1.getPassWord();
			 String rolecomp = user1.getRole();
			 
			 System.out.println(passcomp+"1   "+rolecomp+"2    "+password+"3   "+logintype+"   4");
			 
			 if ((passcomp.equals(password)) && (rolecomp.equals(logintype))){
		     HttpSession session = request.getSession();
			 session.setAttribute("username",username);
             session.setAttribute("role",rolecomp);		
					
					showPage(response, rolecomp); 

			 }
		 else
		 { 
			showPage1(response, "Login Failure! Username and Password did not match.");
		 }
			}
			else
			{ 
				showPage1(response, "Login Failure! Username and Password did not match.");}
			}
											
		  else 
		  {
            showPage1(response, "Login Failure! Username and Password did not match.");
          }
    
		
	}
	
	protected void showPage(HttpServletResponse response, String message) throws ServletException, java.io.IOException {
		
		System.out.println(message);
		if (message.equals("admin"))
		{
        response.setContentType("text/html");
        java.io.PrintWriter out = response.getWriter();
		response.sendRedirect("manager.html");
		}
		else if (message.equals("retailer")) 
		{			
			response.setContentType("text/html");
            java.io.PrintWriter out = response.getWriter();
		    response.sendRedirect("salesmen.html");
		}
		else
		{
			response.setContentType("text/html");
            java.io.PrintWriter out = response.getWriter();
		    response.sendRedirect("DealMatches");
	    }

	}
	
	
	 protected void showPage1(HttpServletResponse response, String message) throws ServletException, java.io.IOException {
		
		response.setContentType("text/html");
        java.io.PrintWriter out = response.getWriter();
					



	out.println("<!doctype html>");
	   out.println("<html lang='en'>");
	   out.println("<head>");
	   out.println("<meta charset='utf-8' name='viewport' content='width=device-width, initial-scale=1.0' name='description' content=''>");
	   out.println("<meta name='author' content=''>");
	   out.println("<title>Home | Smart Portables</title>");
	   out.println("<link href='css/bootstrap.min.css' rel='stylesheet'>");
	   out.println("<link href='css/font-awesome.min.css' rel='stylesheet'>");
	   out.println("<link href='css/main.css' rel='stylesheet'>");
	   out.println("</head><!--/head-->");
	   out.println("<body>");
	   out.println("<header id='header'><!--header-->");
	   out.println("<div class='header-middle'><!--header-middle-->");
	   out.println("<div class='container'>");
	   out.println("<div class='row'>");
	   out.println("<div class='col-sm-4'>");
	   out.println("<div class='logo pull-left'>");
	   out.println("<a href='index.html'><img src='images/home/logo.jpg' alt='' /></a>");
	   out.println("</div>");
	   out.println("</div>");
	   out.println("<div class='col-sm-8'>");
	   out.println("<div class='shop-menu pull-right'>");
	   out.println("<ul class='nav navbar-nav'>");
	   out.println("<li><a href='vieworder.html'><i class='fa fa-user'></i> View Order</a></li>");
	   out.println("<li><a href='signup.html'><i class='fa fa-lock'></i> Sign-Up</a></li>");
	   out.println("<li><a href='login.html'><i class='fa fa-lock'></i> Login</a></li>");
	      out.println("<li><a href='cart.html'><i class='fa fa-shopping-cart'></i> Cart</a></li>");
	   out.println("</ul>");
	   out.println("</div></div></div></div></div><!--/header-middle-->");
	   out.println("<div class='header-bottom'><!--header-bottom-->");
	   out.println("<div class='container'>");
	   out.println("<div class='row'>");
	   out.println("<div class='col-sm-9'>");
	   out.println("<div class='navbar-header'>");
	   out.println("<button type='button' class='navbar-toggle' data-toggle='collapse' data-target='.navbar-collapse'>");
	   out.println("<span class='sr-only'>Toggle navigation</span>");
	   out.println("<span class='icon-bar'></span>");
	   out.println("<span class='icon-bar'></span>");
	   out.println("<span class='icon-bar'></span>");
	   out.println("</button>");
	   out.println("</div>");
	   out.println("<div class='mainmenu pull-left'>");
	   out.println("<ul class='nav navbar-nav collapse navbar-collapse'>");
	   out.println("<li><a href='index.html' class='active'>Home</a></li>");
	   out.println("<li><a href='login.html' target='content'>Smart Watches</a></li>");
	   out.println("<li><a href='login.html' target='content'>Speakers</a></li>");
	   out.println("<li><a href='login.html' target='content'>Headphones</a></li>");
	   out.println("<li><a href='login.html' target='content'>Phones</a></li>");
	   out.println("<li><a href='login.html' target='content'>Laptops</a></li>");
	   out.println("<li><a href='login.html' target='content'>External Storage</a></li>");
	   out.println("</ul>");
	   out.println("</div></div></div></div></div><!--/header-bottom-->");
	   out.println("</header><!--/header-->");
	   
	   out.println("<section>");
	   out.println("<div class='container'>");
	   out.println("<div class='row'>");
	   out.println("<div class='col-sm-3'>");
	   out.println("<div class='left-sidebar'>");
	   out.println("<h2>Category</h2>");
	   out.println("<div class='panel-group category-products' id='accordian'><!--category-productsr-->");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=smartwatches'>Smart Watches</a>");
	   out.println("</h4>");
	   out.println("</div></div>");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=speakers'>Speakers</a>");
	   out.println("</h4>");
	   out.println("</div></div>");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=headphones'>HeadPhones</a>");
	   out.println("</h4>");
	   out.println("</div></div>");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=phones'>Phones</a>");
	   out.println("</h4>");
	   out.println("</div></div>");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=laptops'>laptops</a>");
	   out.println("</h4>");
	   out.println("</div></div>");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=externalstorage'>External Storage</a>");
	   out.println("</h4>");
	   out.println("</div></div>");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=accessory'>Accessories</a>");
	   out.println("</h4>");
	   out.println("</div>");
	   out.println("</div>");
	   out.println("</div><!--/category-products-->");
	   
	  
	   out.println("</div></div>");
	   
	   out.println("<div class='col-sm-9 padding-right'>");
	   out.println("<div class='features_items'><!--features_items-->");
	   out.println("<section id=\'content\'>");

	    out.println("<article>");
        out.println("<h3>" + message + "</h3>"); 
     	out.println("</article>");
        out.println("</section>");
		
 out.println("</div><!--features_items-->");
	   out.println("</div>");
	   out.println("</div>");
	   out.println("</div>");
	   out.println("</section>");
	   
	   out.println("<footer id='footer'><!--Footer-->");
	   out.println("<div class='footer-bottom'>");
	   out.println("<div class='container'>");
	   out.println("<div class='row'>");
	   out.println("<p class='pull-left'>Copyright © 2017 Smart Portables Inc. All rights reserved.</p>");
	   out.println("<p class='pull-right'>Designed by <span><a target='_blank' href='https://www.linkedin.com/in/abhishek-vijhani'>Abhishek Vijhani</a></span></p>");
	   out.println("</div>");
	   out.println("</div>");
	   out.println("</div>");
	   out.println("</footer><!--/Footer-->");
	   out.println("</body>");
	   out.println("</html>");
	   
	   }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processRequest(request, response);
    }
}
