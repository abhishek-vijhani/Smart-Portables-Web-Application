import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/Startup")

/*
startup servlet Initializes HashMap in SaxParserDataStore
*/

public class Startup extends HttpServlet
{
	public void init() throws ServletException
	{

		
		SaxParser4SmartPortables.addHashMap();
		 MySqlDataStoreUtilities.deletetable();
		MySqlDataStoreUtilities.createtable();
		String  Filename= "C:/apache-tomcat-7.0.34/webapps/csj/WEB-INF/ProductCatalog.xml";
		SaxParser4SmartPortables smartportables = new SaxParser4SmartPortables(Filename);
	   //MySqlDataStoreUtilities.insertProduct(smartportables.);
	   MySqlDataStoreUtilities.insertProductSpeakers(smartportables.speakers);
	   MySqlDataStoreUtilities.insertProductSmartwatches(smartportables.smartwatches);
	   MySqlDataStoreUtilities.insertProductPhones(smartportables.phones);
	   MySqlDataStoreUtilities.insertProductHeadphones(smartportables.headphones);
	   MySqlDataStoreUtilities.insertProductES(smartportables.externalstorage);
	   MySqlDataStoreUtilities.insertProductLaptop(smartportables.laptops);
	   MySqlDataStoreUtilities.insertProductAccessories(smartportables.accessories);

	}
}