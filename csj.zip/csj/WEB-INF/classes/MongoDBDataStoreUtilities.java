import com.mongodb.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.lang.Object;



public class MongoDBDataStoreUtilities
{
	

 public static void insertReviews(String productname,String producttype,String price,String retailername,String retailerzip,String retailercity,String retailerstate,String onsale,String manufacturename,String rebate,String userid,String userage,String gender,String occupation,String rating,String reviewdate,String reviewtext)
{    
    try{
		System.out.println("abhishek");
	MongoClient mongo  = new MongoClient("localhost", 27017);
     DB db = mongo.getDB("smartportables");
    DBCollection myReviews= db.getCollection("customerreviews");
	 BasicDBObject doc = new BasicDBObject("title", "customerreviews").
            append("Productname", productname).
            append("producttype", producttype).
           append("Price", price).
            append("Retailername", retailername).
			append("Retailerzip", retailerzip).
            append("Retailercity", retailercity).
           append("Retailerstate", retailerstate).
            append("Onssale", onsale).
			append("Manufacturename", manufacturename).
            append("Rebate", rebate).
           append("Username", userid).
            append("Userage", userage).
			append("Gender", gender).
            append("Occupation", occupation).
           append("Rating", rating).
            append("Reviewdate", reviewdate).
			append("ReviewText", reviewtext);
           myReviews.insert(doc);
		   System.out.println("cool");
	}catch(Exception e){ System.out.println(e.getMessage());}
 }
 
 
 
 
 
 

 

 
 
 public static ArrayList<Review> selectReviews(String prodcutname){
	    ArrayList<Review> Reviews = new ArrayList<Review>();
	 try{
		System.out.println("abhishek");
	    MongoClient mongo  = new MongoClient("localhost", 27017);
        DB db = mongo.getDB("smartportables");
        DBCollection myReviews= db.getCollection("customerreviews");
		 BasicDBObject whereQuery = new BasicDBObject();
        whereQuery.put("Productname", prodcutname);
		System.out.println(prodcutname);
		HashMap < String, ArrayList < Review >> reviewHashmap = new HashMap < String, ArrayList < Review >> ();
        DBCursor cursor = myReviews.find(whereQuery);
        while(cursor.hasNext()) {
			System.out.println("query running");
          DBObject obj = cursor.next();
		  
		  if (!reviewHashmap.containsKey(obj.get("Productname").toString())) {
    ArrayList < Review > arr = new ArrayList < Review > ();
    reviewHashmap.put(obj.get("Productname").toString(), arr);
   }

		  String prodcutnm = obj.get("Productname").toString();
		  String producttype = obj.get("producttype").toString();
		  String retailer = obj.get("Retailername").toString();
		 
		  String username = obj.get("Username").toString();
		  String reviewdate = obj.get("Reviewdate").toString();
		  String reviewtext = obj.get("ReviewText").toString();
		  String rating = obj.get("Rating").toString();
		  String retailerzip = obj.get("Retailerzip").toString();
		  String retailercity = obj.get("Retailercity").toString();
		  String retailerstate = obj.get("Retailerstate").toString();
		 
		  String onsale = obj.get("Onssale").toString();
		  String manufacturename = obj.get("Manufacturename").toString();
		  String rebate = obj.get("Rebate").toString();
		  String userage = obj.get("Userage").toString();
		  
		  String gender = obj.get("Gender").toString();
		  String occupation = obj.get("Occupation").toString();
		 
		 
		   
		  Review review = new Review (prodcutnm,producttype,reviewdate,reviewtext,rating,username,retailer,retailerzip,retailercity,retailerstate,onsale,manufacturename,rebate,userage,gender,occupation);
          System.out.println(review);
          System.out.println(prodcutnm); 		  
		  Reviews.add(review);
		  
		} 
 }catch(Exception e){ System.out.println(e.getMessage());}
 return Reviews;}
 
 
 

   public static  ArrayList <Bestrating> topProducts(){
	  ArrayList <Bestrating> Bestrate = new ArrayList <Bestrating> ();
	  try{
		  System.out.println("bestrating");
	  MongoClient mongo  = new MongoClient("localhost", 27017);
      DB db = mongo.getDB("smartportables");
      DBCollection myReviews= db.getCollection("customerreviews");
	  int retlimit =5;
	  DBObject sort = new BasicDBObject();
	  sort.put("Rating",-1);
	  DBCursor cursor = myReviews.find().limit(retlimit).sort(sort);
	  DBObject res;
	  while(cursor.hasNext()) {
		  res = cursor.next();
		System.out.println(res);
		String prodcutname =(res.get("Productname")).toString();
        String count = (res.get("Rating")).toString();	
        Bestrating mostsld = new Bestrating(prodcutname,count);
		Bestrate.add(mostsld);
	  }
	
	}catch (Exception e){ System.out.println(e.getMessage());}
   return Bestrate;
  }
  
  
  public static ArrayList <Mostsold> mostsoldProducts(){
	  ArrayList <Mostsold> mostsold = new ArrayList <Mostsold> ();
	  try{
		  System.out.println("top5");
	  MongoClient mongo  = new MongoClient("localhost", 27017);
      DB db = mongo.getDB("smartportables");
      DBCollection myReviews= db.getCollection("customerreviews");
      DBObject groupProducts = new BasicDBObject("_id","$Productname"); 
	  groupProducts.put("count",new BasicDBObject("$sum",1));
	  DBObject group = new BasicDBObject("$group",groupProducts);
	  DBObject limit=new BasicDBObject();
      limit=new BasicDBObject("$limit",5);
	  
	  DBObject sortFields = new BasicDBObject("count",-1);
	  DBObject sort = new BasicDBObject("$sort",sortFields);
	  AggregationOutput output = myReviews.aggregate(group,sort,limit);
	  System.out.println(output);
      for (DBObject res : output.results()) {
        System.out.println(res);
		String prodcutname =(res.get("_id")).toString();
        String count = (res.get("count")).toString();	
        Mostsold mostsld = new Mostsold(prodcutname,count);
		mostsold.add(mostsld);
	
	  }
	  
	 
	  
	}catch (Exception e){ System.out.println(e.getMessage());}
      return mostsold;
  }	  
	  
	  public static ArrayList <Mostsoldzip> mostsoldZip(){
	  ArrayList <Mostsoldzip> mostsoldzip = new ArrayList <Mostsoldzip> ();
	  try{
		  System.out.println("top5");
	  MongoClient mongo  = new MongoClient("localhost", 27017);
      DB db = mongo.getDB("smartportables");
      DBCollection myReviews= db.getCollection("customerreviews");
      DBObject groupProducts = new BasicDBObject("_id","$Retailerzip"); 
	  groupProducts.put("count",new BasicDBObject("$sum",1));
	  DBObject group = new BasicDBObject("$group",groupProducts);
	  DBObject limit=new BasicDBObject();
      limit=new BasicDBObject("$limit",5);
	  
	  DBObject sortFields = new BasicDBObject("count",-1);
	  DBObject sort = new BasicDBObject("$sort",sortFields);
	  AggregationOutput output = myReviews.aggregate(group,sort,limit);
      for (DBObject res : output.results()) {
        System.out.println(res);
		String zipcode =(res.get("_id")).toString();
        String count = (res.get("count")).toString();	
        Mostsoldzip mostsldzip = new Mostsoldzip(zipcode,count);
		mostsoldzip.add(mostsldzip);
	
	  }
	  
	 
	  
	}catch (Exception e){ System.out.println(e.getMessage());}
      return mostsoldzip;
  }
  
 }


