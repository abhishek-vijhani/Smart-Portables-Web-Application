import java.util.HashMap;
import java.util.Map;
import java.util.List;


public class AbhishekAccessory {
	String producttype;
    String retailer;
    String name;
    String id;
    String image;
    String condition;
    int price;
	int discount;

void setId(String id) {
	this.id = id;
}

void setDiscount(int discount) {
	this.discount = discount;
}

int getDiscount() {
	return discount;
}

void setProducttype(String producttype) {
	this.producttype = producttype;
}


void setRetailer(String retailer) {
	this.retailer = retailer;
}

void setImage(String image) {
	this.image = image;
}

void setCondition(String condition) {
	this.condition = condition;
}

void setPrice(int price) {
	this.price = price;
}

void setName(String name) {
	this.name = name;
}

String getId() {
	return id;
}

String getProducttype() {
	return producttype;
}

String getRetailer() {
	return retailer;
}

String getImage() {
	return image;
}

String getCondition() {
	return condition;
}

int getPrice() {
	return price;
}

String getName() {
	return name;
}

}
