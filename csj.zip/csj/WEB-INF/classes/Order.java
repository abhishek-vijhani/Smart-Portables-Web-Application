import java.io.*;
public class Order implements Serializable
{

String username ;
int ordernumber;
String deliverydate;
String orderdate;
String productid;
String productname;
Double price;

public  Order(String username,int ordernumber,String orderdate,String deliverydate,String productid,String productname,Double price)
{
	
	this.username = username;
	this.ordernumber = ordernumber;
	this.deliverydate = deliverydate;
	this.orderdate = orderdate;
	this.productid = productid;
	this.productname = productname;
	this.price = price;

}
//void setuserid(String userid) {
//	this.id = id;
//}

public String getUsername(){
 return username;
}

public int getOrdernumber () {
 return ordernumber;
}

public String getDeliverydate(){
return deliverydate;
}
public String getOrderdate(){
 return orderdate;
}

public String getProductid () {
 return productid;
}

public String getProductname(){
return productname;
}

public Double getPrice(){
	return price;
}


}