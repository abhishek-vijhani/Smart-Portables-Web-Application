import java.util.ArrayList;
import java.util.List;

	
public class SalesBean {

    String totalsales;
    String productname;
    int price;
    int totalnumber;

	
	public SalesBean()
	{}

    public SalesBean(String totalsales,String productname,int price,int totalnumber){
        this.totalsales = totalsales;
		this.productname = productname;
		this.price = price;
		this.totalnumber = totalnumber;
    }

	public String getTotalSales() {
		return totalsales;
	}



	public String getProductName() {
		return productname;
	}


	public int getPrice() {
		return price;
	}
	
	public int getTotalNumber() {
		return totalnumber;
	}

   
	
}