import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;



////////////////////////////////////////////////////////////

/**************

SAX parser use callback function  to notify client object of the XML document structure. 
You should extend DefaultHandler and override the method when parsin the XML document

***************/

////////////////////////////////////////////////////////////

public class SaxParser4SmartPortables extends DefaultHandler {
    LaptopsTest laptop;
	SmartwatchesTest smartwatch;
	SpeakersTest speaker;
	HeadphoneTest headphone;
	PhonesTest phone; 
	ESTest externalstore;
	AccessoryTest accessory;
	
	static HashMap<String,LaptopsTest> laptops;
	static HashMap<String,SmartwatchesTest> smartwatches;
	static HashMap<String,SpeakersTest> speakers;
	static HashMap<String,PhonesTest> phones;
	static HashMap<String,ESTest> externalstorage;
	static HashMap<String,AccessoryTest> accessories;
	static HashMap<String,HeadphoneTest> headphones;
	
	HashMap<String, String> accesoryHashMap;
    String consoleXmlFileName;
    String elementValueRead;
	String currentElement="";
	public SaxParser4SmartPortables()
	{
		
	}
	
    public SaxParser4SmartPortables(String consoleXmlFileName) {
        this.consoleXmlFileName = consoleXmlFileName;
        smartwatches = new HashMap<String,SmartwatchesTest>();
		speakers = new HashMap<String,SpeakersTest>();
		headphones = new HashMap<String,HeadphoneTest>();
		phones = new HashMap<String,PhonesTest>();
		laptops = new HashMap<String,LaptopsTest>();
		externalstorage = new HashMap<String,ESTest>();
		accessories = new HashMap<String,AccessoryTest>();
		accesoryHashMap = new HashMap<String,String>();
	
        parseDocument();
		
        
    }
	


    private void parseDocument() {
        SAXParserFactory factory = SAXParserFactory.newInstance();
        try {
            SAXParser parser = factory.newSAXParser();
            parser.parse(consoleXmlFileName, this);
        } catch (ParserConfigurationException e) {
            System.out.println("ParserConfig error");
        } catch (SAXException e) {
            System.out.println("SAXException : Xml Not Well Formed");
        } catch (IOException e) {
            System.out.println("IO error");
        }
    }


  
////////////////////////////////////////////////////////////

/*************

There are a number of methods to override in SAX handler  when parsing your XML document :

    Group 1. startDocument() and endDocument() :  Methods that are called at the start and end of an XML document. 
    Group 2. startElement() and endElement() :  Methods that are called  at the start and end of a document element.  
    Group 3. characters() : Method that is called with the text content in between the start and end tags of an XML document element.


There are few other methods that you could use for notification for different purposes, check the API at the following URL:

https://docs.oracle.com/javase/7/docs/api/org/xml/sax/helpers/DefaultHandler.html

***************/

////////////////////////////////////////////////////////////

    @Override
    public void startElement(String str1, String str2, String elementName, Attributes attributes) throws SAXException {

		
        if (elementName.equalsIgnoreCase("smartwatch")) {
			currentElement="smartwatch";
            smartwatch = new SmartwatchesTest();
            smartwatch.setId(attributes.getValue("id"));
            smartwatch.setRetailer(attributes.getValue("retailer"));
        }
		if (elementName.equalsIgnoreCase("laptop")) {
			currentElement="laptop";
            laptop = new LaptopsTest();
            laptop.setId(attributes.getValue("id"));
            laptop.setRetailer(attributes.getValue("retailer"));
        }
		
		if (elementName.equalsIgnoreCase("headphone")) {
			currentElement="headphone";
            headphone = new HeadphoneTest();
            headphone.setId(attributes.getValue("id"));
            headphone.setRetailer(attributes.getValue("retailer"));
			
        }
		
		if (elementName.equalsIgnoreCase("speaker")) {
			currentElement="speaker";
            speaker = new SpeakersTest();
            speaker.setId(attributes.getValue("id"));
            speaker.setRetailer(attributes.getValue("retailer"));
        }
		if (elementName.equalsIgnoreCase("phone")) {
			currentElement="phone";
            phone = new PhonesTest();
            phone.setId(attributes.getValue("id"));
            phone.setRetailer(attributes.getValue("retailer"));
        }
		if (elementName.equalsIgnoreCase("externalstorage")) {
			currentElement="externalstorage";
            externalstore = new ESTest();
            externalstore.setId(attributes.getValue("id"));
            externalstore.setRetailer(attributes.getValue("retailer"));
        }
		if (elementName.equalsIgnoreCase("accessory") && !currentElement.equals("laptop"))  {
			currentElement="accessory";
            accessory = new AccessoryTest();
            accessory.setId(attributes.getValue("id"));
            accessory.setRetailer(attributes.getValue("retailer"));
        }


    }

    @Override
    public void endElement(String str1, String str2, String element) throws SAXException {

        if (element.equals("smartwatch")) {
			smartwatches.put(smartwatch.getId(),smartwatch);
			return;
        }
		if (element.equalsIgnoreCase("laptop")) {
			laptops.put(laptop.getId(),laptop);
			return;
        }
		if (element.equals("headphone")) {
			headphones.put(headphone.getId(),headphone);
			return;
        }
		if (element.equals("speaker")) {
			speakers.put(speaker.getId(),speaker);
			return;
        }
		if (element.equals("phone")) {
			phones.put(phone.getId(),phone);
			return;
        }
		if (element.equals("externalstorage")) {
			externalstorage.put(externalstore.getId(),externalstore);
			return;
        }
		if (element.equals("accessory") && currentElement.equals("accessory")) {
			accessories.put(accessory.getId(),accessory);
			return;
        }
		
		
		if (element.equals("accessory") && currentElement.equals("accessories")) {
			accesoryHashMap.put(elementValueRead, elementValueRead);
			for (Entry<String, String> entry : accesoryHashMap.entrySet()) {
				String temp2 = entry.getValue();
				System.out.println("Checking accessory values: "+temp2);
			}
			return;
        }
			
		
		if (element.equals("accessories") && currentElement.equals("laptop")) {
			accesoryHashMap.put(elementValueRead,elementValueRead);
			laptop.setAccessories(accesoryHashMap);
			accesoryHashMap = new HashMap<String, String>();
			return;
        }
		
		if(element.equalsIgnoreCase("price")){
			if(currentElement.equals("laptop"))
				laptop.setPrice(Integer.parseInt(elementValueRead));
			if(currentElement.equals("smartwatch"))
				smartwatch.setPrice(Integer.parseInt(elementValueRead));
			if(currentElement.equals("headphone"))
				headphone.setPrice(Integer.parseInt(elementValueRead));
			if(currentElement.equals("speaker"))
				speaker.setPrice(Integer.parseInt(elementValueRead));
			if(currentElement.equals("phone"))
				phone.setPrice(Integer.parseInt(elementValueRead));
			if(currentElement.equals("externalstorage"))
				externalstore.setPrice(Integer.parseInt(elementValueRead));
			if(currentElement.equals("accessory"))
				accessory.setPrice(Integer.parseInt(elementValueRead));
			return;
		}
		
		if(element.equalsIgnoreCase("productname")){
			if(currentElement.equals("laptop"))
				laptop.setName(elementValueRead);
			if(currentElement.equals("smartwatch"))
				smartwatch.setName(elementValueRead);
			if(currentElement.equals("headphone") )
				headphone.setName(elementValueRead);
			if(currentElement.equals("speaker"))
				speaker.setName(elementValueRead);
			if(currentElement.equals("phone"))
				phone.setName(elementValueRead);
			if(currentElement.equals("externalstorage"))
				externalstore.setName(elementValueRead);
			if(currentElement.equals("accessory"))
				accessory.setName(elementValueRead);
			return;
		}
		
		if(element.equalsIgnoreCase("condition")){
			if(currentElement.equals("laptop"))
				laptop.setCondition(elementValueRead);
			if(currentElement.equals("smartwatch"))
				smartwatch.setCondition(elementValueRead);
			if(currentElement.equals("headphone"))
				headphone.setCondition(elementValueRead);
			if(currentElement.equals("speaker"))
				speaker.setCondition(elementValueRead);
			if(currentElement.equals("phone"))
				phone.setCondition(elementValueRead);
			if(currentElement.equals("externalstorage"))
				externalstore.setCondition(elementValueRead);
			if(currentElement.equals("accessory"))
				accessory.setCondition(elementValueRead);
			return;
		}
		if(element.equalsIgnoreCase("Producttype")){
			if(currentElement.equals("laptop"))
				laptop.setProducttype(elementValueRead);
			if(currentElement.equals("smartwatch"))
				smartwatch.setProducttype(elementValueRead);
			if(currentElement.equals("headphone"))
				headphone.setProducttype(elementValueRead);
			if(currentElement.equals("speaker"))
				speaker.setProducttype(elementValueRead);
			if(currentElement.equals("phone"))
				phone.setProducttype(elementValueRead);
			if(currentElement.equals("externalstorage"))
				externalstore.setProducttype(elementValueRead);
			if(currentElement.equals("accessory"))
				accessory.setProducttype(elementValueRead);
			return;
		}
		
		
		if(element.equalsIgnoreCase("image")){
			if(currentElement.equals("laptop"))
				laptop.setImage(elementValueRead);
			if(currentElement.equals("smartwatch"))
				smartwatch.setImage(elementValueRead);
			if(currentElement.equals("headphone"))
				headphone.setImage(elementValueRead);
			if(currentElement.equals("speaker"))
				speaker.setImage(elementValueRead);
			if(currentElement.equals("phone"))
				phone.setImage(elementValueRead);
			if(currentElement.equals("externalstorage"))
				externalstore.setImage(elementValueRead);
			if(currentElement.equals("accessory"))
				accessory.setImage(elementValueRead);
			return;
		}
		
		
		if(element.equalsIgnoreCase("rebate")){
			if(currentElement.equals("laptop"))
				laptop.setRebate(elementValueRead);
			if(currentElement.equals("smartwatch"))
				smartwatch.setRebate(elementValueRead);
			if(currentElement.equals("headphone"))
				headphone.setRebate(elementValueRead);
			if(currentElement.equals("speaker"))
				speaker.setRebate(elementValueRead);
			if(currentElement.equals("phone"))
				phone.setRebate(elementValueRead);
			if(currentElement.equals("externalstorage"))
				externalstore.setRebate(elementValueRead);
			if(currentElement.equals("accessory"))
				accessory.setRebate(elementValueRead);
			return;
		}
		
		
		if(element.equalsIgnoreCase("sale")){
			if(currentElement.equals("laptop"))
				laptop.setSale(elementValueRead);
			if(currentElement.equals("smartwatch"))
				smartwatch.setSale(elementValueRead);
			if(currentElement.equals("headphone"))
				headphone.setSale(elementValueRead);
			if(currentElement.equals("speaker"))
				speaker.setSale(elementValueRead);
			if(currentElement.equals("phone"))
				phone.setSale(elementValueRead);
			if(currentElement.equals("externalstorage"))
				externalstore.setSale(elementValueRead);
			if(currentElement.equals("accessory"))
				accessory.setSale(elementValueRead);
			return;
		}
		
		
		if(element.equalsIgnoreCase("quantity")){
			if(currentElement.equals("laptop"))
				laptop.setQuantity(Integer.parseInt(elementValueRead));
			if(currentElement.equals("smartwatch"))
				smartwatch.setQuantity(Integer.parseInt(elementValueRead));
			if(currentElement.equals("headphone"))
				headphone.setQuantity(Integer.parseInt(elementValueRead));
			if(currentElement.equals("speaker"))
				speaker.setQuantity(Integer.parseInt(elementValueRead));
			if(currentElement.equals("phone"))
				phone.setQuantity(Integer.parseInt(elementValueRead));
			if(currentElement.equals("externalstorage"))
				externalstore.setQuantity(Integer.parseInt(elementValueRead));
			if(currentElement.equals("accessory"))
				accessory.setQuantity(Integer.parseInt(elementValueRead));
			return;
		}

    }

    @Override
    public void characters(char[] content, int begin, int end) throws SAXException {
        elementValueRead = new String(content, begin, end);
    }


    /////////////////////////////////////////
    // 	     Kick-Start SAX in main       //
    ////////////////////////////////////////


	public static void addHashMap()
	{	
		 String TOMCAT_HOME = System.getProperty("catalina.home");
		new SaxParser4SmartPortables(TOMCAT_HOME+"\\webapps\\csj\\WEB-INF\\ProductCatalog.xml");
		
	}
	
	
	
}




