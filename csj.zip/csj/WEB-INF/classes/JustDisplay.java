import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Map.Entry;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class JustDisplay extends HttpServlet {
	
PrintWriter out = null;
  String CategoryName = "";
  

  static HashMap<String,List<AbhishekAccessory>> accessoryMap = new HashMap<String,List<AbhishekAccessory>>();
  
  
  static List<AbhishekAccessory> dellAccessory = new ArrayList<AbhishekAccessory>();
  static List<AbhishekAccessory> appleAccessory = new ArrayList<AbhishekAccessory>();
  static List<AbhishekAccessory> microsoftAccessory = new ArrayList<AbhishekAccessory>();
  static List<AbhishekAccessory> asusAccessory = new ArrayList<AbhishekAccessory>();
  static List<AbhishekAccessory> hpAccessory = new ArrayList<AbhishekAccessory>();
  static List<AbhishekAccessory> samsungAccessory = new ArrayList<AbhishekAccessory>();
  
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	  
	  
	  HttpSession session = request.getSession();
		 String role = (String)session.getAttribute("role");
		 
		 String viewreview = "/csj/ViewreviewServlet";
		String writereview = "/csj/ReviewServlet";
		String orderpage = "/csj/OrderServlet";
		 response.setContentType("text/html");
		 out = response.getWriter();
		 String name = null;
		 CategoryName = request.getParameter("maker");

		HashMap<String, LaptopsTest> alistLaptop = new HashMap<String, LaptopsTest>();
		HashMap<String, SmartwatchesTest> alistSmartwatches = new HashMap<String, SmartwatchesTest>();
		HashMap<String, PhonesTest> alistPhones = new HashMap<String, PhonesTest>();
		HashMap<String, SpeakersTest> alistSpeakers = new HashMap<String, SpeakersTest>();
		HashMap<String, HeadphoneTest> alistHeadphones = new HashMap<String, HeadphoneTest>();
		HashMap<String, ESTest> alistES = new HashMap<String, ESTest>();
		HashMap<String, AccessoryTest> alistAccessory = new HashMap<String, AccessoryTest>();
		
		HashMap<String, Object> temp = new HashMap<String, Object>();
		
	if (CategoryName != null){
		if (CategoryName.equalsIgnoreCase("laptops")){
			temp.putAll(SaxParser4SmartPortables.laptops);
			//System.out.println("list"+temp);
			name = "";	
		}
		if(CategoryName.equalsIgnoreCase("smartwatches")){
		
			temp.putAll(SaxParser4SmartPortables.smartwatches);
			//System.out.println("list"+temp);

			name = "";
		}
		if(CategoryName.equalsIgnoreCase("phones")){

			temp.putAll(SaxParser4SmartPortables.phones);
			//System.out.println("list"+alistPhones);
			name = "";
		}
		if(CategoryName.equalsIgnoreCase("speakers")){

			temp.putAll(SaxParser4SmartPortables.speakers);
			//System.out.println("list"+alistSpeakers);
			name = "";
		}
		if(CategoryName.equalsIgnoreCase("headphones")){

			temp.putAll(SaxParser4SmartPortables.headphones);
			//System.out.println("list"+alistHeadphones);
			name = "";
		}
		if(CategoryName.equalsIgnoreCase("externalstorage")){

			temp.putAll(SaxParser4SmartPortables.externalstorage);
			//System.out.println("list"+alistES);
			name = "";
		}
		if(CategoryName.equalsIgnoreCase("accessory")){

			temp.putAll(SaxParser4SmartPortables.accessories);
			//System.out.println("list"+alistAccessory);
			name = "";
		}
	 
	

		
	

	
	  out.println("<!doctype html>");
	   out.println("<html lang='en'>");
	   out.println("<head>");
	   out.println("<meta charset='utf-8' name='viewport' content='width=device-width, initial-scale=1.0' name='description' content=''>");
	   out.println("<meta name='author' content=''>");
	   out.println("<title>Home | Smart Portables</title>");
	   out.println("<link href='css/bootstrap.min.css' rel='stylesheet'>");
	   out.println("<link href='css/font-awesome.min.css' rel='stylesheet'>");
	   out.println("<link href='css/main.css' rel='stylesheet'>");
	   out.println("</head><!--/head-->");
	   out.println("<body>");
	   out.println("<header id='header'><!--header-->");
	   out.println("<div class='header-middle'><!--header-middle-->");
	   out.println("<div class='container'>");
	   out.println("<div class='row'>");
	   out.println("<div class='col-sm-4'>");
	   out.println("<div class='logo pull-left'>");
	   out.println("<a href='index.html'><img src='images/home/logo.jpg' alt='' /></a>");
	   out.println("</div>");
	   out.println("</div>");
	   out.println("<div class='col-sm-8'>");
	   out.println("<div class='shop-menu pull-right'>");
	   out.println("<ul class='nav navbar-nav'>");
	   out.println("<li><a href='vieworder.html'><i class='fa fa-user'></i> View Order</a></li>");
	   out.println("<li><a href='signup.html'><i class='fa fa-lock'></i> Sign-Up</a></li>");
	   out.println("<li><a href='login.html'><i class='fa fa-lock'></i> Login</a></li>");
	      out.println("<li><a href='cart.html'><i class='fa fa-shopping-cart'></i> Cart</a></li>");
	   out.println("</ul>");
	   out.println("</div></div></div></div></div><!--/header-middle-->");
	   out.println("<div class='header-bottom'><!--header-bottom-->");
	   out.println("<div class='container'>");
	   out.println("<div class='row'>");
	   out.println("<div class='col-sm-9'>");
	   out.println("<div class='navbar-header'>");
	   out.println("<button type='button' class='navbar-toggle' data-toggle='collapse' data-target='.navbar-collapse'>");
	   out.println("<span class='sr-only'>Toggle navigation</span>");
	   out.println("<span class='icon-bar'></span>");
	   out.println("<span class='icon-bar'></span>");
	   out.println("<span class='icon-bar'></span>");
	   out.println("</button>");
	   out.println("</div>");
	   out.println("<div class='mainmenu pull-left'>");
	   out.println("<ul class='nav navbar-nav collapse navbar-collapse'>");
	   out.println("<li><a href='index.html' class='active'>Home</a></li>");
	   out.println("<li><a href='login.html' target='content'>Smart Watches</a></li>");
	   out.println("<li><a href='login.html' target='content'>Speakers</a></li>");
	   out.println("<li><a href='login.html' target='content'>Headphones</a></li>");
	   out.println("<li><a href='login.html' target='content'>Phones</a></li>");
	   out.println("<li><a href='login.html' target='content'>Laptops</a></li>");
	   out.println("<li><a href='login.html' target='content'>External Storage</a></li>");
	   out.println("</ul>");
	   out.println("</div></div>");
	   out.println("<div class='col-sm-3'>");
						out.println("<div class='search_box pull-right'>");
							out.println("<input type='text' placeholder='Search' name='searchId' value='' class='input' id='searchId' onkeyup='doCompletion()'/>");
							out.println("<div id='auto-row' align='right' width='315 px' >");
							out.println("<table id='complete-table' class='gridtable' style='align= right; width:315 px;'></table>");
							out.println("</div>");
						out.println("</div>");
					out.println("</div>");
	  out.println(" </div></div></div><!--/header-bottom-->");
	   out.println("</header><!--/header-->");
	   
	   out.println("<section>");
	   out.println("<div class='container'>");
	   out.println("<div class='row'>");
	   out.println("<div class='col-sm-3'>");
	   out.println("<div class='left-sidebar'>");
	   out.println("<h2>Category</h2>");
	   out.println("<div class='panel-group category-products' id='accordian'><!--category-productsr-->");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=smartwatches'>Smart Watches</a>");
	   out.println("</h4>");
	   out.println("</div></div>");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=speakers'>Speakers</a>");
	   out.println("</h4>");
	   out.println("</div></div>");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=headphones'>HeadPhones</a>");
	   out.println("</h4>");
	   out.println("</div></div>");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=phones'>Phones</a>");
	   out.println("</h4>");
	   out.println("</div></div>");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=laptops'>laptops</a>");
	   out.println("</h4>");
	   out.println("</div></div>");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=externalstorage'>External Storage</a>");
	   out.println("</h4>");
	   out.println("</div></div>");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=accessory'>Accessories</a>");
	   out.println("</h4>");
	   out.println("</div>");
	   out.println("</div>");
	   out.println("</div><!--/category-products-->");
	   
	  
	   out.println("</div></div>");
	   
	   out.println("<div class='col-sm-9 padding-right'>");
	   out.println("<div class='features_items'><!--features_items-->");
	   out.println("<section id=\'content\'>");
	   
	   listAllLaptops(temp);
	   putLaptopAndAccessory(temp, SaxParser4SmartPortables.accessories);
	
  
	 
	 out.println("</section>");
		
 out.println("</div><!--features_items-->");
	   out.println("</div>");
	   out.println("</div>");
	   out.println("</div>");
	   out.println("</section>");
	   
	   out.println("<footer id='footer'><!--Footer-->");
	   out.println("<div class='footer-bottom'>");
	   out.println("<div class='container'>");
	   out.println("<div class='row'>");
	   out.println("<p class='pull-left'>Copyright © 2017 Smart Portables Inc. All rights reserved.</p>");
	   out.println("<p class='pull-right'>Designed by <span><a target='_blank' href='https://www.linkedin.com/in/abhishek-vijhani'>Abhishek Vijhani</a></span></p>");
	   out.println("</div>");
	   out.println("</div>");
	   out.println("</div>");
	   out.println("</footer><!--/Footer-->");
	   out.println("</body>");
	   out.println("</html>");
	   
  }
}

public void putLaptopAndAccessory(HashMap<String, Object> temp, Map<String, AccessoryTest> saxParserMap)
 {
	 String image = "";
	 String name = "";
	 String productType = "";
	 String condition = "";
	 String retailer = "";
	 int price = 0;
	 String productId = "";
	 int count = 0;
	 
	 //for accessories
	 String accImage = "";
	 String accName = "";
	 String accProductType = "";
	 String accCondition = "";
	 String accRetailer = "";
	 int accPrice = 0;
	 String accProductId = "";
	 
	 List<AbhishekAccessory> accessoryList = null;
	 
	 AbhishekAccessory abhishekAccessory = null;
	 
	 
	  for (Entry<String, AccessoryTest> entry : saxParserMap.entrySet()) 
	  {
		   
				   AccessoryTest accessoryTest = (AccessoryTest) entry.getValue();
				   //System.out.println("Accessory Name: "+accessoryTest.getName());
				   if(accessoryTest.getName().contains("Dell"))
				   {
					   abhishekAccessory = new AbhishekAccessory();
					   abhishekAccessory.setId(accessoryTest.getId());
								abhishekAccessory.setName(accessoryTest.getName());
								abhishekAccessory.setImage(accessoryTest.getImage());
								abhishekAccessory.setCondition(accessoryTest.getCondition());
								abhishekAccessory.setPrice(accessoryTest.getPrice());
								abhishekAccessory.setProducttype(accessoryTest.getProducttype());
								
								dellAccessory.add(abhishekAccessory);
				   }
				   
				   
				   if(accessoryTest.getName().contains("Microsoft"))
				   {
					   abhishekAccessory = new AbhishekAccessory();
					   abhishekAccessory.setId(accessoryTest.getId());
								abhishekAccessory.setName(accessoryTest.getName());
								abhishekAccessory.setImage(accessoryTest.getImage());
								abhishekAccessory.setCondition(accessoryTest.getCondition());
								abhishekAccessory.setPrice(accessoryTest.getPrice());
								abhishekAccessory.setProducttype(accessoryTest.getProducttype());
								
								microsoftAccessory.add(abhishekAccessory);
				   }
				   if(accessoryTest.getName().contains("Asus"))
				   {
					   abhishekAccessory = new AbhishekAccessory();
					   abhishekAccessory.setId(accessoryTest.getId());
								abhishekAccessory.setName(accessoryTest.getName());
								abhishekAccessory.setImage(accessoryTest.getImage());
								abhishekAccessory.setCondition(accessoryTest.getCondition());
								abhishekAccessory.setPrice(accessoryTest.getPrice());
								abhishekAccessory.setProducttype(accessoryTest.getProducttype());
								
								asusAccessory.add(abhishekAccessory);
				   }
				   if(accessoryTest.getName().contains("Samsung"))
				   {
					   abhishekAccessory = new AbhishekAccessory();
					   abhishekAccessory.setId(accessoryTest.getId());
								abhishekAccessory.setName(accessoryTest.getName());
								abhishekAccessory.setImage(accessoryTest.getImage());
								abhishekAccessory.setCondition(accessoryTest.getCondition());
								abhishekAccessory.setPrice(accessoryTest.getPrice());
								abhishekAccessory.setProducttype(accessoryTest.getProducttype());
								
								samsungAccessory.add(abhishekAccessory);
				   }
				   if(accessoryTest.getName().contains("HP"))
				   {
					   abhishekAccessory = new AbhishekAccessory();
					   abhishekAccessory.setId(accessoryTest.getId());
								abhishekAccessory.setName(accessoryTest.getName());
								abhishekAccessory.setImage(accessoryTest.getImage());
								abhishekAccessory.setCondition(accessoryTest.getCondition());
								abhishekAccessory.setPrice(accessoryTest.getPrice());
								abhishekAccessory.setProducttype(accessoryTest.getProducttype());
								
								hpAccessory.add(abhishekAccessory);
				   }
				   if(accessoryTest.getName().contains("Apple"))
				   {
					   abhishekAccessory = new AbhishekAccessory();
					   abhishekAccessory.setId(accessoryTest.getId());
								abhishekAccessory.setName(accessoryTest.getName());
								abhishekAccessory.setImage(accessoryTest.getImage());
								abhishekAccessory.setCondition(accessoryTest.getCondition());
								abhishekAccessory.setPrice(accessoryTest.getPrice());
								abhishekAccessory.setProducttype(accessoryTest.getProducttype());
								
								appleAccessory.add(abhishekAccessory);
				   }
		}
	 
	 	 
 }

 public void listAllLaptops(HashMap<String, Object> temp)
 {
	 String image = "";
	 String name = "";
	 String productType = "";
	 String condition = "";
	 String retailer = "";
	 int price = 0;
	 String productId = "";
	 
	 for (Entry<String, Object> entry : temp.entrySet()) {
		   if(CategoryName!=null)
		   {
			   if(CategoryName.equalsIgnoreCase("laptops"))
			   {
				   LaptopsTest tempObject = (LaptopsTest) entry.getValue();
					image = tempObject.getImage();
				  name = tempObject.getName();
				   productType = tempObject.getProducttype();
				   condition = tempObject.getCondition();
				   retailer = tempObject.getRetailer();
				   price = tempObject.getPrice();
				   productId = tempObject.getId();
				   
			   }
			   else if(CategoryName.equalsIgnoreCase("smartwatches"))
			   {
				   SmartwatchesTest tempObject1 = (SmartwatchesTest) entry.getValue();
					image = tempObject1.getImage();
				  name = tempObject1.getName();
				   productType = tempObject1.getProducttype();
				   condition = tempObject1.getCondition();
				   retailer = tempObject1.getRetailer();
				   price = tempObject1.getPrice();
				   productId = tempObject1.getId();
			   }
			   else if(CategoryName.equalsIgnoreCase("headphones"))
			   {
				   HeadphoneTest tempObject2 = (HeadphoneTest) entry.getValue();;
					image = tempObject2.getImage();
				  name = tempObject2.getName();
				   productType = tempObject2.getProducttype();
				   condition = tempObject2.getCondition();
				   retailer = tempObject2.getRetailer();
				   price = tempObject2.getPrice();
				   productId = tempObject2.getId();
			   }
			   else if(CategoryName.equalsIgnoreCase("speakers"))
			   {
				   SpeakersTest tempObject3 = (SpeakersTest) entry.getValue();;
					image = tempObject3.getImage();
				  name = tempObject3.getName();
				   productType = tempObject3.getProducttype();
				   condition = tempObject3.getCondition();
				   retailer = tempObject3.getRetailer();
				   price = tempObject3.getPrice();
				   productId = tempObject3.getId();
			   }
			   else if(CategoryName.equalsIgnoreCase("phones"))
			   {
				   PhonesTest tempObject4 = (PhonesTest) entry.getValue();;
					image = tempObject4.getImage();
				  name = tempObject4.getName();
				   productType = tempObject4.getProducttype();
				   condition = tempObject4.getCondition();
				   retailer = tempObject4.getRetailer();
				   price = tempObject4.getPrice();
				   productId = tempObject4.getId();
			   }
			   else if(CategoryName.equalsIgnoreCase("externalstorage"))
			   {
				   ESTest tempObject5 = (ESTest) entry.getValue();;
					image = tempObject5.getImage();
				  name = tempObject5.getName();
				   productType = tempObject5.getProducttype();
				   condition = tempObject5.getCondition();
				   retailer = tempObject5.getRetailer();
				   price = tempObject5.getPrice();
				   productId = tempObject5.getId();
			   }
			   else 
			   {
				   AccessoryTest tempObject6 = (AccessoryTest) entry.getValue();;
				   image = tempObject6.getImage();
				   name = tempObject6.getName();
				   productType = tempObject6.getProducttype();
				   condition = tempObject6.getCondition();
				   retailer = tempObject6.getRetailer();
				   price = tempObject6.getPrice();
				   productId = tempObject6.getId();
			   }
			   
		   }
		   
			//LaptopsTest laptop = (LaptopsTest) entry.getValue();
		out.println("<div class='col-sm-4'>");
		out.println("<div class='product-image-wrapper'>");
		out.println("<div class='single-products'>");
		out.println("<div class='productinfo text-center'>");
		out.println(image);
		out.println("<h2>"+name+"</h2>");
		out.println("<p>"+productType+"</p>");
		out.println("<p>"+condition+"</p>");
		out.println("<p>"+retailer+"</p>");
		out.println("<p>"+price+"</p>");
		out.println("<form  action='/csj/OrderServlet'>");
		out.println("<input type='hidden' value= " + productId +" name='productid' />");
		out.println("<input type='hidden' value= "+name+" name='productname' />");
		out.println("<input type='hidden' value= "+price+" name='price' />");
		out.println("<input type='hidden' value= "+productType+" name='producttype' />");
		out.println("<input type='hidden' value= "+retailer+" name='retailer' />");
		out.println("<button type='submit' class='btn btn-default' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
		out.println("</form>");
		
		out.println("<ul class='nav nav-pills nav-justified'>");
		out.println("<form  action='/csj/ViewreviewServlet'>");
		out.println("<input type='hidden' value= " + name +" name='productname' />");
		out.println("<li><button type='submit' class='btn btn-default' value='View review'>View Reviews</button></li>");
		out.println("</form>");
		out.println("<form  action='/csj/ReviewServlet'>");
		out.println("<input type='hidden' value= " + name +" name='productname' />");
		out.println("<input type='hidden' value= "+retailer+" name='retailer' />");
		out.println("<input type='hidden' value= "+price+" name='price' />");
		out.println("<input type='hidden' value= "+productType+" name='producttype' />");
		out.println("<li><button type='submit' class='btn btn-default' value='Write review'>Write Review</button></li>");
		out.println("</form>");
		out.println("</ul>");
		
		
		
		
		out.println("<br>");
		out.println("</div>");
		out.println("</div>");	
		out.println("</div>");
		out.println("</div>");
	   }
 }

	  


	   

}

