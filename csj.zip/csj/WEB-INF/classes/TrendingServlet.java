import java.util.HashMap;
import java.util.Map;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.text.*;
import java.util.*;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.FileInputStream;

public class TrendingServlet extends HttpServlet {
	
	ArrayList <Mostsold> mostsold = new ArrayList <Mostsold> ();
    ArrayList <Mostsoldzip> mostsoldzip = new ArrayList <Mostsoldzip> ();
	ArrayList <Bestrating> bestra = new ArrayList <Bestrating> ();
	
    String ordernum;
	String productid;
	String productname;
	int quantity;
	double price;
	String deliverydate;
	String orderdate;
	String username;
	Integer ordernumber;
	String msg;
	String userid;
	
		 
		
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    
	mostsold = MongoDBDataStoreUtilities.mostsoldProducts();
	mostsoldzip = MongoDBDataStoreUtilities.mostsoldZip();
	bestra      = MongoDBDataStoreUtilities.topProducts();
	
    response.setContentType("text/html");
    PrintWriter out = response.getWriter();
	
    	

			
		out.println("<!doctype html>");
	   out.println("<html lang='en'>");
	   out.println("<head>");
	   out.println("<meta charset='utf-8' name='viewport' content='width=device-width, initial-scale=1.0' name='description' content=''>");
	   out.println("<meta name='author' content=''>");
	   out.println("<title>Home | Smart Portables</title>");
	   out.println("<link href='css/bootstrap.min.css' rel='stylesheet'>");
	   out.println("<link href='css/font-awesome.min.css' rel='stylesheet'>");
	   out.println("<link href='css/main.css' rel='stylesheet'>");
	   out.println("</head><!--/head-->");
	   out.println("<body>");
	   out.println("<header id='header'><!--header-->");
	   out.println("<div class='header-middle'><!--header-middle-->");
	   out.println("<div class='container'>");
	   out.println("<div class='row'>");
	   out.println("<div class='col-sm-4'>");
	   out.println("<div class='logo pull-left'>");
	   out.println("<a href='index.html'><img src='images/home/logo.jpg' alt='' /></a>");
	   out.println("</div>");
	   out.println("</div>");
	   out.println("<div class='col-sm-8'>");
	   out.println("<div class='shop-menu pull-right'>");
	   out.println("<ul class='nav navbar-nav'>");
	   out.println("<li><a href='vieworder.html'><i class='fa fa-user'></i> View Order</a></li>");
	   out.println("<li><a href='signup.html'><i class='fa fa-lock'></i> Sign-Up</a></li>");
	   out.println("<li><a href='login.html'><i class='fa fa-lock'></i> Login</a></li>");
	      out.println("<li><a href='cart.html'><i class='fa fa-shopping-cart'></i> Cart</a></li>");
	   out.println("</ul>");
	   out.println("</div></div></div></div></div><!--/header-middle-->");
	   out.println("<div class='header-bottom'><!--header-bottom-->");
	   out.println("<div class='container'>");
	   out.println("<div class='row'>");
	   out.println("<div class='col-sm-9'>");
	   out.println("<div class='navbar-header'>");
	   out.println("<button type='button' class='navbar-toggle' data-toggle='collapse' data-target='.navbar-collapse'>");
	   out.println("<span class='sr-only'>Toggle navigation</span>");
	   out.println("<span class='icon-bar'></span>");
	   out.println("<span class='icon-bar'></span>");
	   out.println("<span class='icon-bar'></span>");
	   out.println("</button>");
	   out.println("</div>");
	   out.println("<div class='mainmenu pull-left'>");
	   out.println("<ul class='nav navbar-nav collapse navbar-collapse'>");
	   out.println("<li><a href='index.html' class='active'>Home</a></li>");
	   out.println("<li><a href='login.html' target='content'>Smart Watches</a></li>");
	   out.println("<li><a href='login.html' target='content'>Speakers</a></li>");
	   out.println("<li><a href='login.html' target='content'>Headphones</a></li>");
	   out.println("<li><a href='login.html' target='content'>Phones</a></li>");
	   out.println("<li><a href='login.html' target='content'>Laptops</a></li>");
	   out.println("<li><a href='login.html' target='content'>External Storage</a></li>");
	   out.println("</ul>");
	   out.println("</div></div>");
	   out.println("<div class='col-sm-3'>");
						out.println("<div class='search_box pull-right'>");
							out.println("<input type='text' placeholder='Search' name='searchId' value='' class='input' id='searchId' onkeyup='doCompletion()'/>");
							out.println("<div id='auto-row' align='right' width='315 px' >");
							out.println("<table id='complete-table' class='gridtable' style='align= right; width:315 px;'></table>");
							out.println("</div>");
						out.println("</div>");
					out.println("</div>");
	  out.println(" </div></div></div><!--/header-bottom-->");
	   out.println("</header><!--/header-->");
	   
	   out.println("<section>");
	   out.println("<div class='container'>");
	   out.println("<div class='row'>");
	   out.println("<div class='col-sm-3'>");
	   out.println("<div class='left-sidebar'>");
	   out.println("<h2>Category</h2>");
	   out.println("<div class='panel-group category-products' id='accordian'><!--category-productsr-->");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=smartwatches'>Smart Watches</a>");
	   out.println("</h4>");
	   out.println("</div></div>");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=speakers'>Speakers</a>");
	   out.println("</h4>");
	   out.println("</div></div>");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=headphones'>HeadPhones</a>");
	   out.println("</h4>");
	   out.println("</div></div>");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=phones'>Phones</a>");
	   out.println("</h4>");
	   out.println("</div></div>");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=laptops'>laptops</a>");
	   out.println("</h4>");
	   out.println("</div></div>");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=externalstorage'>External Storage</a>");
	   out.println("</h4>");
	   out.println("</div></div>");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=accessory'>Accessories</a>");
	   out.println("</h4>");
	   out.println("</div>");
	   out.println("</div>");
	   out.println("</div><!--/category-products-->");
	   
	  
	   out.println("</div></div>");
	   
	   out.println("<div class='col-sm-9 padding-right'>");
	   out.println("<div class='features_items'><!--features_items-->");
	   out.println("<section id=\'content\'>");
	   
	   
	   
	   
	   


		out.println("<h4>Most Liked Product </h4>"); 
		out.println("<table>");
		Iterator itr2 = bestra.iterator();
        while(itr2.hasNext()) {
         Bestrating best = (Bestrating)itr2.next();
 		out.println("<tr>");
		out.println("<td border: 1px >");
		out.println(best.getProductname());
		out.println("</td>");
		out.println("<td border: 1px >");
		out.println(best.getRating());
		out.println("</td>");
		out.println("</tr>");
        }
		out.println("</table>");
		
        out.println("<h4>Most Sold Product Irrespective of Rating </h4>"); 
		out.println("<table>");
		Iterator itr = mostsold.iterator();
        while(itr.hasNext()) {
         Mostsold most = (Mostsold)itr.next();
 		out.println("<tr>");
		out.println("<td border: 1px >");
		out.println(most.getProductname());
		out.println("</td>");
		out.println("<td border: 1px >");
		out.println(most.getCount());
		out.println("</td>");
		out.println("</tr>");
        }
		out.println("</table>");
		
		out.println("<h4>Top 5 Zips where Maximum Number of Products Reviewed</h4>"); 
		out.println("<table>");
		Iterator itr1 = mostsoldzip.iterator();
		System.out.println(mostsoldzip.size());
        while(itr1.hasNext()) {
         Mostsoldzip mostzip = (Mostsoldzip)itr1.next();
 		out.println("<tr>");
		out.println("<td border: 1px >");
		System.out.println(mostzip.getZipcode());
		out.println(mostzip.getZipcode());
		out.println("</td>");
		out.println("<td border: 1px >");
		out.println(mostzip.getCount());
		out.println("</td>");
		out.println("</tr>");
        }
		out.println("</table>");
		
     	
		
		
		out.println("</section>");
		
		out.println("</div><!--features_items-->");
	   out.println("</div>");
	   out.println("</div>");
	   out.println("</div>");
	   out.println("</section>");
	   
	   out.println("<footer id='footer'><!--Footer-->");
	   out.println("<div class='footer-bottom'>");
	   out.println("<div class='container'>");
	   out.println("<div class='row'>");
	   out.println("<p class='pull-left'>Copyright © 2017 Smart Portables Inc. All rights reserved.</p>");
	   out.println("<p class='pull-right'>Designed by <span><a target='_blank' href='https://www.linkedin.com/in/abhishek-vijhani'>Abhishek Vijhani</a></span></p>");
	   out.println("</div>");
	   out.println("</div>");
	   out.println("</div>");
	   out.println("</footer><!--/Footer-->");
	   out.println("</body>");
	   out.println("</html>");
}
}