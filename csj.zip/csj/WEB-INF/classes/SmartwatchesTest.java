

import java.util.ArrayList;
import java.util.List;


public class SmartwatchesTest {
	String producttype;
    String retailer;
    String name;
    String id;
    String image;
    String condition;
	String rebate;
	String sale;
	int quantity;
    int price;
    List<String> accessories;
    public SmartwatchesTest(){
        accessories=new ArrayList<String>();
    }

void setId(String id) {
	this.id = id;
}


void setProducttype(String producttype) {
	this.producttype = producttype;
}


void setRetailer(String retailer) {
	this.retailer = retailer;
}

void setImage(String image) {
	this.image = image;
}

void setCondition(String condition) {
	this.condition = condition;
}

void setPrice(int price) {
	this.price = price;
}

List getAccessories() {
	return accessories;
}


void setName(String name) {
	this.name = name;
}

String getId() {
	return id;
}

String getProducttype() {
	return producttype;
}

String getRetailer() {
	return retailer;
}

String getImage() {
	return image;
}

String getCondition() {
	return condition;
}

int getPrice() {
	return price;
}

String getName() {
	return name;
}

void setQuantity(int quantity) {
	this.quantity = quantity;
}

int getQuantity() {
	return quantity;
}

void setRebate(String rebate) {
	this.rebate = rebate;
}

String getRebate() {
	return rebate;
}

void setSale(String sale) {
	this.sale = sale;
}

String getSale() {
	return sale;
}


}
