import java.util.HashMap;
import java.util.Map;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.text.*;
import java.util.*;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.FileInputStream;

public class DeletecartServlet extends HttpServlet {

 HashMap <String ,Cart > Deletecart = new HashMap<String , Cart> ();
  public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
	  
	  HttpSession session = request.getSession();
	 
      Deletecart = (HashMap)session.getAttribute("shoppingCart");
	  String productid = request.getParameter("productid");
	  Deletecart.remove(productid);
	  session.setAttribute("shoppingCart", Deletecart);
	  
	  response.setContentType("text/html");
      PrintWriter out = response.getWriter();
	  
	  
	  
	  
	  out.println("<!doctype html>");
	   out.println("<html lang='en'>");
	   out.println("<head>");
	   out.println("<meta charset='utf-8' name='viewport' content='width=device-width, initial-scale=1.0' name='description' content=''>");
	   out.println("<meta name='author' content=''>");
	   out.println("<title>Home | Smart Portables</title>");
	   out.println("<link href='css/bootstrap.min.css' rel='stylesheet'>");
	   out.println("<link href='css/font-awesome.min.css' rel='stylesheet'>");
	   out.println("<link href='css/main.css' rel='stylesheet'>");
	   out.println("</head><!--/head-->");
	   out.println("<body>");
	   out.println("<header id='header'><!--header-->");
	   out.println("<div class='header-middle'><!--header-middle-->");
	   out.println("<div class='container'>");
	   out.println("<div class='row'>");
	   out.println("<div class='col-sm-4'>");
	   out.println("<div class='logo pull-left'>");
	   out.println("<a href='index.html'><img src='images/home/logo.jpg' alt='' /></a>");
	   out.println("</div>");
	   out.println("</div>");
	   out.println("<div class='col-sm-8'>");
	   out.println("<div class='shop-menu pull-right'>");
	   out.println("<ul class='nav navbar-nav'>");
	   out.println("<li><a href='vieworder.html'><i class='fa fa-user'></i> View Order</a></li>");
	   out.println("<li><a href='signup.html'><i class='fa fa-lock'></i> Sign-Up</a></li>");
	   out.println("<li><a href='login.html'><i class='fa fa-lock'></i> Login</a></li>");
	      out.println("<li><a href='cart.html'><i class='fa fa-shopping-cart'></i> Cart</a></li>");
	   out.println("</ul>");
	   out.println("</div></div></div></div></div><!--/header-middle-->");
	   out.println("<div class='header-bottom'><!--header-bottom-->");
	   out.println("<div class='container'>");
	   out.println("<div class='row'>");
	   out.println("<div class='col-sm-9'>");
	   out.println("<div class='navbar-header'>");
	   out.println("<button type='button' class='navbar-toggle' data-toggle='collapse' data-target='.navbar-collapse'>");
	   out.println("<span class='sr-only'>Toggle navigation</span>");
	   out.println("<span class='icon-bar'></span>");
	   out.println("<span class='icon-bar'></span>");
	   out.println("<span class='icon-bar'></span>");
	   out.println("</button>");
	   out.println("</div>");
	   out.println("<div class='mainmenu pull-left'>");
	   out.println("<ul class='nav navbar-nav collapse navbar-collapse'>");
	   out.println("<li><a href='index.html' class='active'>Home</a></li>");
	   out.println("<li><a href='login.html' target='content'>Smart Watches</a></li>");
	   out.println("<li><a href='login.html' target='content'>Speakers</a></li>");
	   out.println("<li><a href='login.html' target='content'>Headphones</a></li>");
	   out.println("<li><a href='login.html' target='content'>Phones</a></li>");
	   out.println("<li><a href='login.html' target='content'>Laptops</a></li>");
	   out.println("<li><a href='login.html' target='content'>External Storage</a></li>");
	   out.println("</ul>");
	   out.println("</div></div>");
	   out.println("<div class='col-sm-3'>");
						out.println("<div class='search_box pull-right'>");
							out.println("<input type='text' placeholder='Search' name='searchId' value='' class='input' id='searchId' onkeyup='doCompletion()'/>");
							out.println("<div id='auto-row' align='right' width='315 px' >");
							out.println("<table id='complete-table' class='gridtable' style='align= right; width:315 px;'></table>");
							out.println("</div>");
						out.println("</div>");
					out.println("</div>");
	  out.println(" </div></div></div><!--/header-bottom-->");
	   out.println("</header><!--/header-->");
	   
	   out.println("<section>");
	   out.println("<div class='container'>");
	   out.println("<div class='row'>");
	   out.println("<div class='col-sm-3'>");
	   out.println("<div class='left-sidebar'>");
	   out.println("<h2>Category</h2>");
	   out.println("<div class='panel-group category-products' id='accordian'><!--category-productsr-->");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=smartwatches'>Smart Watches</a>");
	   out.println("</h4>");
	   out.println("</div></div>");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=speakers'>Speakers</a>");
	   out.println("</h4>");
	   out.println("</div></div>");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=headphones'>HeadPhones</a>");
	   out.println("</h4>");
	   out.println("</div></div>");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=phones'>Phones</a>");
	   out.println("</h4>");
	   out.println("</div></div>");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=laptops'>laptops</a>");
	   out.println("</h4>");
	   out.println("</div></div>");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=externalstorage'>External Storage</a>");
	   out.println("</h4>");
	   out.println("</div></div>");
	   out.println("<div class='panel panel-default'>");
	   out.println("<div class='panel-heading'>");
	   out.println("<h4 class='panel-title'>");
	   out.println("<a href='JustDisplay?maker=accessory'>Accessories</a>");
	   out.println("</h4>");
	   out.println("</div>");
	   out.println("</div>");
	   out.println("</div><!--/category-products-->");
	   
	  
	   out.println("</div></div>");
	   
	   out.println("<div class='col-sm-9 padding-right'>");
	   out.println("<div class='features_items'><!--features_items-->");
	   out.println("<section id=\'content\'>");
		
		
		
		


		out.println("<table style='width:80%'>");
		out.println("<tr>");
              out.println("<th>");
              out.println("Product ID");
              out.println("</th>");
			  out.println("<th>");
              out.println("Product Name");
              out.println("</th>");
			  out.println("<th>");
              out.println("Product Quantity");
              out.println("</th>");
			  out.println("<th>");
              out.println("Product Price");
              out.println("</th>");
			  out.println("</tr>");
	    
     double total = 0;
	 Set set = Deletecart.entrySet();
      Iterator iterator = set.iterator();
      while(iterator.hasNext()) {
         Map.Entry mentry = (Map.Entry)iterator.next();
         
         Cart cart1 = (Cart)mentry.getValue();
              String disproductid = cart1.getProductid();
              String disproductname = cart1.getProductname();
			  int disquantity = cart1.getQuantity();
              double disprice = cart1.getPrice();
			  total = total + disprice;
			  out.println("<tr>");
              out.println("<td>");
              out.println(disproductid);
              out.println("</td>");
              out.println("<td>");
              out.println(disproductname);
              out.println("</td>");
              out.println("<td>");
              out.println(disquantity);
              out.println("</td>");
              out.println("<td>");
              out.println(disprice);
              out.println("</td>"); 
			  out.println("<td>");
			  out.println("<form  action='/csj/DeletecartServlet'>");
			  out.println("<input type='hidden' value= " + disproductid +" name='productid' />");
			  out.println("<button type='submit' class='btn btn-default' value='Cancel'>Delete</button>");
			  out.println("</form>");
			  out.println("</td>");
			  out.println("</tr>");
              			  
      }
	         out.println("<tr>");
			 out.println("<td></td><td></td><td></td><td></td><td></td>");
			 out.println("</tr>");
			 out.println("<tr>");
			 out.println("<td>");
			 out.println("<b>Total : </b>"+ total);
			 out.println("</td>");
			 out.println("</tr>");
			 out.println("<tr>");
			 out.println("<td>");
			 out.println("<form  action='/csj/CheckoutServlet'>");
			 out.println("<button type='submit' class='btn btn-default' value='Checkout'>Checkout</button>");
			 out.println("</form>");
			 out.println("</td>"); 
         	 out.println("</tr>");
			 out.println("</table>");

		Set set1 = Deletecart.entrySet();
      Iterator iterator1 = set1.iterator();
      while(iterator1.hasNext()) {
         Map.Entry mentry = (Map.Entry)iterator1.next();
         
         Cart cart2 = (Cart)mentry.getValue();
              String disretailer = cart2.getRetailer();
              String disproducttype = cart2.getProducttype();
			
			  
							

				
				if (disproducttype.equalsIgnoreCase("laptops") && disretailer.equalsIgnoreCase("Dell"))
				{
					int did[] = new int[100];
					String name[] = new String[100];
					String image[] = new String[100];
					String condition[] = new String[100];
					int dprice[] = new int[100];
					String type[] = new String[100];
					String dretailer[] = new String[100];
					  int i=0;
					for(AbhishekAccessory obj1: JustDisplay.dellAccessory)
				   {

								did[i] = Integer.parseInt(obj1.getId());
								name[i] = obj1.getName();
								image[i] = obj1.getImage();
								condition[i] = obj1.getCondition();
								dprice[i] = obj1.getPrice();
								type[i] = obj1.getProducttype();
								dretailer[i] = obj1.getRetailer();
								i++;
							
				   }
				  

								out.println("<div id='slider-carousel' data-ride='carousel' class='carousel slide'>");
					
								out.println("<ol class='carousel-indicators'>");
								out.println("<li data-target='#slider-carousel' data-slide-to='0' class='active'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='1'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='2'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='3'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='4'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='5'></li>");
								out.println("</ol>");
						
								out.println("<div class='carousel-inner'>");
						
								out.println("<div class='item active'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[0]+"</h1>");
								out.println("<h2>"+type[0]+"</h2>");
								out.println("<h2>"+dprice[0]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[0] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[0]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[0]+" name='price' />");
								out.println("<input type='hidden' value= "+type[0]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[0]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</form>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[0]+" />");
								out.println("</div>");
								out.println("</div>");

							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[1]+"</h1>");
								out.println("<h2>"+type[1]+"</h2>");
								out.println("<h2>"+dprice[1]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[1] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[1]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[1]+" name='price' />");
								out.println("<input type='hidden' value= "+type[1]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[1]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[1]+" />");
								out.println("</div>");
								out.println("</div>");
							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[2]+"</h1>");
								out.println("<h2>"+type[2]+"</h2>");
								out.println("<h2>"+dprice[2]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[2] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[2]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[2]+" name='price' />");
								out.println("<input type='hidden' value= "+type[2]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[2]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[2]+" />");
								out.println("</div>");
								out.println("</div>");
							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[3]+"</h1>");
								out.println("<h2>"+type[3]+"</h2>");
								out.println("<h2>"+dprice[3]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[3] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[3]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[3]+" name='price' />");
								out.println("<input type='hidden' value= "+type[3]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[3]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[3]+" />");
								out.println("</div>");
								out.println("</div>");
							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[4]+"</h1>");
								out.println("<h2>"+type[4]+"</h2>");
								out.println("<h2>"+dprice[4]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[4] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[4]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[4]+" name='price' />");
								out.println("<input type='hidden' value= "+type[4]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[4]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[4]+" />");
								out.println("</div>");
								out.println("</div>");
							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[5]+"</h1>");
								out.println("<h2>"+type[5]+"</h2>");
								out.println("<h2>"+dprice[5]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[5] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[5]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[5]+" name='price' />");
								out.println("<input type='hidden' value= "+type[5]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[5]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[5]+" />");
								out.println("</div>");
								out.println("</div>");
							
							

							
								out.println("</div>");
						
								out.println("<a class='left carousel-control' href='#slider-carousel' data-slide='prev'>");
      out.println("<span class='glyphicon glyphicon-chevron-left'></span>");
     out.println(" <span class='sr-only'>Previous</span>");
   out.println(" </a>");
    out.println("<a class='right carousel-control' href='#slider-carousel' data-slide='next'>");
      out.println("<span class='glyphicon glyphicon-chevron-right'></span>");
     out.println(" <span class='sr-only'>Next</span>");
   out.println(" </a> ");
								out.println("</div>");
					
	
				}

				else if (disproducttype.equalsIgnoreCase("laptops") && disretailer.equalsIgnoreCase("hp"))
				{
				
					int did[] = new int[100];
					String name[] = new String[100];
					String image[] = new String[100];
					String condition[] = new String[100];
					int dprice[] = new int[100];
					String type[] = new String[100];
					String dretailer[] = new String[100];
					  int i=0;
					  
					for(AbhishekAccessory obj1: JustDisplay.hpAccessory)
				   {
					   did[i] = Integer.parseInt(obj1.getId());
								name[i] = obj1.getName();
								image[i] = obj1.getImage();
								condition[i] = obj1.getCondition();
								dprice[i] = obj1.getPrice();
								type[i] = obj1.getProducttype();
								dretailer[i] = obj1.getRetailer();
								i++;
				   }
				   
				   out.println("<div id='slider-carousel' data-ride='carousel' class='carousel slide'>");
					
								out.println("<ol class='carousel-indicators'>");
								out.println("<li data-target='#slider-carousel' data-slide-to='0' class='active'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='1'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='2'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='3'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='4'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='5'></li>");
								out.println("</ol>");
						
								out.println("<div class='carousel-inner'>");
						
								out.println("<div class='item active'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[0]+"</h1>");
								out.println("<h2>"+type[0]+"</h2>");
								out.println("<h2>"+dprice[0]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[0] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[0]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[0]+" name='price' />");
								out.println("<input type='hidden' value= "+type[0]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[0]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</form>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[0]+" />");
								out.println("</div>");
								out.println("</div>");

							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[1]+"</h1>");
								out.println("<h2>"+type[1]+"</h2>");
								out.println("<h2>"+dprice[1]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[1] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[1]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[1]+" name='price' />");
								out.println("<input type='hidden' value= "+type[1]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[1]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[1]+" />");
								out.println("</div>");
								out.println("</div>");
							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[2]+"</h1>");
								out.println("<h2>"+type[2]+"</h2>");
								out.println("<h2>"+dprice[2]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[2] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[2]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[2]+" name='price' />");
								out.println("<input type='hidden' value= "+type[2]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[2]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[2]+" />");
								out.println("</div>");
								out.println("</div>");
							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[3]+"</h1>");
								out.println("<h2>"+type[3]+"</h2>");
								out.println("<h2>"+dprice[3]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[3] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[3]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[3]+" name='price' />");
								out.println("<input type='hidden' value= "+type[3]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[3]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[3]+" />");
								out.println("</div>");
								out.println("</div>");
							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[4]+"</h1>");
								out.println("<h2>"+type[4]+"</h2>");
								out.println("<h2>"+dprice[4]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[4] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[4]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[4]+" name='price' />");
								out.println("<input type='hidden' value= "+type[4]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[4]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[4]+" />");
								out.println("</div>");
								out.println("</div>");
							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[5]+"</h1>");
								out.println("<h2>"+type[5]+"</h2>");
								out.println("<h2>"+dprice[5]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[5] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[5]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[5]+" name='price' />");
								out.println("<input type='hidden' value= "+type[5]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[5]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[5]+" />");
								out.println("</div>");
								out.println("</div>");
							
							

							
								out.println("</div>");
						
							out.println("<a class='left carousel-control' href='#slider-carousel' data-slide='prev'>");
      out.println("<span class='glyphicon glyphicon-chevron-left'></span>");
     out.println(" <span class='sr-only'>Previous</span>");
   out.println(" </a>");
    out.println("<a class='right carousel-control' href='#slider-carousel' data-slide='next'>");
      out.println("<span class='glyphicon glyphicon-chevron-right'></span>");
     out.println(" <span class='sr-only'>Next</span>");
   out.println(" </a> ");
								out.println("</div>");
								
								
				}
				else if (disproducttype.equalsIgnoreCase("laptops") && disretailer.equalsIgnoreCase("Apple"))
				{
										int did[] = new int[15];
					String name[] = new String[15];
					String image[] = new String[15];
					String condition[] = new String[15];
					int dprice[] = new int[15];
					String type[] = new String[15];
					String dretailer[] = new String[15];
					  int i=0;
					  
					for(AbhishekAccessory obj1: JustDisplay.appleAccessory)
				   {
					  did[i] = Integer.parseInt(obj1.getId());
								name[i] = obj1.getName();
								image[i] = obj1.getImage();
								condition[i] = obj1.getCondition();
								dprice[i] = obj1.getPrice();
								type[i] = obj1.getProducttype();
								dretailer[i] = obj1.getRetailer();
								i++;
				   }
				   
				   out.println("<div id='slider-carousel' data-ride='carousel' class='carousel slide'>");
					
								out.println("<ol class='carousel-indicators'>");
								out.println("<li data-target='#slider-carousel' data-slide-to='0' class='active'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='1'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='2'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='3'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='4'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='5'></li>");
								out.println("</ol>");
						
								out.println("<div class='carousel-inner'>");
						
								out.println("<div class='item active'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[0]+"</h1>");
								out.println("<h2>"+type[0]+"</h2>");
								out.println("<h2>"+dprice[0]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[0] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[0]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[0]+" name='price' />");
								out.println("<input type='hidden' value= "+type[0]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[0]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</form>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[0]+" />");
								out.println("</div>");
								out.println("</div>");

							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[1]+"</h1>");
								out.println("<h2>"+type[1]+"</h2>");
								out.println("<h2>"+dprice[1]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[1] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[1]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[1]+" name='price' />");
								out.println("<input type='hidden' value= "+type[1]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[1]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[1]+" />");
								out.println("</div>");
								out.println("</div>");
							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[2]+"</h1>");
								out.println("<h2>"+type[2]+"</h2>");
								out.println("<h2>"+dprice[2]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[2] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[2]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[2]+" name='price' />");
								out.println("<input type='hidden' value= "+type[2]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[2]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[2]+" />");
								out.println("</div>");
								out.println("</div>");
							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[3]+"</h1>");
								out.println("<h2>"+type[3]+"</h2>");
								out.println("<h2>"+dprice[3]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[3] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[3]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[3]+" name='price' />");
								out.println("<input type='hidden' value= "+type[3]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[3]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[3]+" />");
								out.println("</div>");
								out.println("</div>");
							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[4]+"</h1>");
								out.println("<h2>"+type[4]+"</h2>");
								out.println("<h2>"+dprice[4]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[4] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[4]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[4]+" name='price' />");
								out.println("<input type='hidden' value= "+type[4]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[4]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[4]+" />");
								out.println("</div>");
								out.println("</div>");
							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[5]+"</h1>");
								out.println("<h2>"+type[5]+"</h2>");
								out.println("<h2>"+dprice[5]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[5] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[5]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[5]+" name='price' />");
								out.println("<input type='hidden' value= "+type[5]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[5]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[5]+" />");
								out.println("</div>");
								out.println("</div>");
							
							

							
								out.println("</div>");
						
						out.println("<a class='left carousel-control' href='#slider-carousel' data-slide='prev'>");
      out.println("<span class='glyphicon glyphicon-chevron-left'></span>");
     out.println(" <span class='sr-only'>Previous</span>");
   out.println(" </a>");
    out.println("<a class='right carousel-control' href='#slider-carousel' data-slide='next'>");
      out.println("<span class='glyphicon glyphicon-chevron-right'></span>");
     out.println(" <span class='sr-only'>Next</span>");
   out.println(" </a> ");
								out.println("</div>");
								
								
				}
				else if (disproducttype.equalsIgnoreCase("laptops") && disretailer.equalsIgnoreCase("microsoft"))
				{
					
					int did[] = new int[15];
					String name[] = new String[15];
					String image[] = new String[15];
					String condition[] = new String[15];
					int dprice[] = new int[15];
					String type[] = new String[15];
					String dretailer[] = new String[15];
					  int i=0;
					  
					for(AbhishekAccessory obj1: JustDisplay.microsoftAccessory)
				   {
					   did[i] = Integer.parseInt(obj1.getId());
								name[i] = obj1.getName();
								image[i] = obj1.getImage();
								condition[i] = obj1.getCondition();
								dprice[i] = obj1.getPrice();
								type[i] = obj1.getProducttype();
								dretailer[i] = obj1.getRetailer();
								i++;
				   }
				   
				   out.println("<div id='slider-carousel' data-ride='carousel' class='carousel slide'>");
					
								out.println("<ol class='carousel-indicators'>");
								out.println("<li data-target='#slider-carousel' data-slide-to='0' class='active'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='1'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='2'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='3'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='4'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='5'></li>");
								out.println("</ol>");
						
								out.println("<div class='carousel-inner'>");
						
								out.println("<div class='item active'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[0]+"</h1>");
								out.println("<h2>"+type[0]+"</h2>");
								out.println("<h2>"+dprice[0]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[0] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[0]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[0]+" name='price' />");
								out.println("<input type='hidden' value= "+type[0]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[0]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</form>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[0]+" />");
								out.println("</div>");
								out.println("</div>");

							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[1]+"</h1>");
								out.println("<h2>"+type[1]+"</h2>");
								out.println("<h2>"+dprice[1]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[1] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[1]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[1]+" name='price' />");
								out.println("<input type='hidden' value= "+type[1]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[1]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[1]+" />");
								out.println("</div>");
								out.println("</div>");
							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[2]+"</h1>");
								out.println("<h2>"+type[2]+"</h2>");
								out.println("<h2>"+dprice[2]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[2] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[2]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[2]+" name='price' />");
								out.println("<input type='hidden' value= "+type[2]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[2]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[2]+" />");
								out.println("</div>");
								out.println("</div>");
							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[3]+"</h1>");
								out.println("<h2>"+type[3]+"</h2>");
								out.println("<h2>"+dprice[3]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[3] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[3]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[3]+" name='price' />");
								out.println("<input type='hidden' value= "+type[3]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[3]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[3]+" />");
								out.println("</div>");
								out.println("</div>");
							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[4]+"</h1>");
								out.println("<h2>"+type[4]+"</h2>");
								out.println("<h2>"+dprice[4]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[4] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[4]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[4]+" name='price' />");
								out.println("<input type='hidden' value= "+type[4]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[4]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[4]+" />");
								out.println("</div>");
								out.println("</div>");
							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[5]+"</h1>");
								out.println("<h2>"+type[5]+"</h2>");
								out.println("<h2>"+dprice[5]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[5] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[5]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[5]+" name='price' />");
								out.println("<input type='hidden' value= "+type[5]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[5]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[5]+" />");
								out.println("</div>");
								out.println("</div>");
							
							

							
								out.println("</div>");
					out.println("<a class='left carousel-control' href='#slider-carousel' data-slide='prev'>");
      out.println("<span class='glyphicon glyphicon-chevron-left'></span>");
     out.println(" <span class='sr-only'>Previous</span>");
   out.println(" </a>");
    out.println("<a class='right carousel-control' href='#slider-carousel' data-slide='next'>");
      out.println("<span class='glyphicon glyphicon-chevron-right'></span>");
     out.println(" <span class='sr-only'>Next</span>");
   out.println(" </a> ");
								out.println("</div>");
								
								
				}
				else if (disproducttype.equalsIgnoreCase("laptops") && disretailer.equalsIgnoreCase("asus"))
				{
					
					int did[] = new int[15];
					String name[] = new String[15];
					String image[] = new String[15];
					String condition[] = new String[15];
					int dprice[] = new int[15];
					String type[] = new String[15];
					String dretailer[] = new String[15];
					  int i=0;
					  
					for(AbhishekAccessory obj1: JustDisplay.asusAccessory)
				   {
					  did[i] = Integer.parseInt(obj1.getId());
								name[i] = obj1.getName();
								image[i] = obj1.getImage();
								condition[i] = obj1.getCondition();
								dprice[i] = obj1.getPrice();
								type[i] = obj1.getProducttype();
								dretailer[i] = obj1.getRetailer();
								i++;
				   }
				   
				   out.println("<div id='slider-carousel' data-ride='carousel' class='carousel slide'>");
					
								out.println("<ol class='carousel-indicators'>");
								out.println("<li data-target='#slider-carousel' data-slide-to='0' class='active'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='1'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='2'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='3'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='4'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='5'></li>");
								out.println("</ol>");
						
								out.println("<div class='carousel-inner'>");
						
								out.println("<div class='item active'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[0]+"</h1>");
								out.println("<h2>"+type[0]+"</h2>");
								out.println("<h2>"+dprice[0]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[0] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[0]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[0]+" name='price' />");
								out.println("<input type='hidden' value= "+type[0]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[0]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</form>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[0]+" />");
								out.println("</div>");
								out.println("</div>");

							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[1]+"</h1>");
								out.println("<h2>"+type[1]+"</h2>");
								out.println("<h2>"+dprice[1]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[1] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[1]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[1]+" name='price' />");
								out.println("<input type='hidden' value= "+type[1]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[1]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[1]+" />");
								out.println("</div>");
								out.println("</div>");
							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[2]+"</h1>");
								out.println("<h2>"+type[2]+"</h2>");
								out.println("<h2>"+dprice[2]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[2] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[2]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[2]+" name='price' />");
								out.println("<input type='hidden' value= "+type[2]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[2]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[2]+" />");
								out.println("</div>");
								out.println("</div>");
							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[3]+"</h1>");
								out.println("<h2>"+type[3]+"</h2>");
								out.println("<h2>"+dprice[3]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[3] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[3]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[3]+" name='price' />");
								out.println("<input type='hidden' value= "+type[3]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[3]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[3]+" />");
								out.println("</div>");
								out.println("</div>");
							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[4]+"</h1>");
								out.println("<h2>"+type[4]+"</h2>");
								out.println("<h2>"+dprice[4]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[4] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[4]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[4]+" name='price' />");
								out.println("<input type='hidden' value= "+type[4]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[4]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[4]+" />");
								out.println("</div>");
								out.println("</div>");
							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[5]+"</h1>");
								out.println("<h2>"+type[5]+"</h2>");
								out.println("<h2>"+dprice[5]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[5] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[5]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[5]+" name='price' />");
								out.println("<input type='hidden' value= "+type[5]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[5]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[5]+" />");
								out.println("</div>");
								out.println("</div>");
							
							

							
								out.println("</div>");
					out.println("<a class='left carousel-control' href='#slider-carousel' data-slide='prev'>");
      out.println("<span class='glyphicon glyphicon-chevron-left'></span>");
     out.println(" <span class='sr-only'>Previous</span>");
   out.println(" </a>");
    out.println("<a class='right carousel-control' href='#slider-carousel' data-slide='next'>");
      out.println("<span class='glyphicon glyphicon-chevron-right'></span>");
     out.println(" <span class='sr-only'>Next</span>");
   out.println(" </a> ");
								out.println("</div>");
								
								
				}
				else 
					//(disproducttype.equalsIgnoreCase("laptops") && disretailer.equalsIgnoreCase("samsung"))
				{
					
					int did[] = new int[15];
					String name[] = new String[15];
					String image[] = new String[15];
					String condition[] = new String[15];
					int dprice[] = new int[15];
					String type[] = new String[15];
					String dretailer[] = new String[15];
					  int i=0;
					  
					  
					for(AbhishekAccessory obj1: JustDisplay.samsungAccessory)
				   {
					   did[i] = Integer.parseInt(obj1.getId());
								name[i] = obj1.getName();
								image[i] = obj1.getImage();
								condition[i] = obj1.getCondition();
								dprice[i] = obj1.getPrice();
								type[i] = obj1.getProducttype();
								dretailer[i] = obj1.getRetailer();
								i++;
				   }
				   
				   out.println("<div id='slider-carousel' data-ride='carousel' class='carousel slide'>");
					
								out.println("<ol class='carousel-indicators'>");
								out.println("<li data-target='#slider-carousel' data-slide-to='0' class='active'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='1'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='2'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='3'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='4'></li>");
								out.println("<li data-target='#slider-carousel' data-slide-to='5'></li>");
								out.println("</ol>");
						
								out.println("<div class='carousel-inner'>");
						
								out.println("<div class='item active'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[0]+"</h1>");
								out.println("<h2>"+type[0]+"</h2>");
								out.println("<h2>"+dprice[0]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[0] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[0]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[0]+" name='price' />");
								out.println("<input type='hidden' value= "+type[0]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[0]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</form>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[0]+" />");
								out.println("</div>");
								out.println("</div>");

							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[1]+"</h1>");
								out.println("<h2>"+type[1]+"</h2>");
								out.println("<h2>"+dprice[1]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[1] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[1]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[1]+" name='price' />");
								out.println("<input type='hidden' value= "+type[1]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[1]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[1]+" />");
								out.println("</div>");
								out.println("</div>");
							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[2]+"</h1>");
								out.println("<h2>"+type[2]+"</h2>");
								out.println("<h2>"+dprice[2]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[2] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[2]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[2]+" name='price' />");
								out.println("<input type='hidden' value= "+type[2]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[2]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[2]+" />");
								out.println("</div>");
								out.println("</div>");
							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[3]+"</h1>");
								out.println("<h2>"+type[3]+"</h2>");
								out.println("<h2>"+dprice[3]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[3] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[3]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[3]+" name='price' />");
								out.println("<input type='hidden' value= "+type[3]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[3]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[3]+" />");
								out.println("</div>");
								out.println("</div>");
							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[4]+"</h1>");
								out.println("<h2>"+type[4]+"</h2>");
								out.println("<h2>"+dprice[4]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[4] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[4]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[4]+" name='price' />");
								out.println("<input type='hidden' value= "+type[4]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[4]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[4]+" />");
								out.println("</div>");
								out.println("</div>");
							
								out.println("<div class='item'>");
								out.println("<div class='col-sm-6'>");
								out.println("<h1>" +name[5]+"</h1>");
								out.println("<h2>"+type[5]+"</h2>");
								out.println("<h2>"+dprice[5]+"</h2>");
								out.println("<form  action='/csj/OrderServlet'>");
								out.println("<input type='hidden' value= " + did[5] +" name='productid' />");
								out.println("<input type='hidden' value= "+name[5]+" name='productname' />");
								out.println("<input type='hidden' value= "+dprice[5]+" name='price' />");
								out.println("<input type='hidden' value= "+type[5]+" name='producttype' />");
								out.println("<input type='hidden' value= "+dretailer[5]+" name='retailer' />");
								out.println("<button type='submit' class='btn btn-default get' value='AddtoShoppingCart'>Add to Shopping Cart</button>");
								out.println("</div>");
								out.println("<div class='col-sm-6'>");
								out.println("<img src= "+image[5]+" />");
								out.println("</div>");
								out.println("</div>");
							
							

							
								out.println("</div>");
						
					out.println("<a class='left carousel-control' href='#slider-carousel' data-slide='prev'>");
      out.println("<span class='glyphicon glyphicon-chevron-left'></span>");
     out.println(" <span class='sr-only'>Previous</span>");
   out.println(" </a>");
    out.println("<a class='right carousel-control' href='#slider-carousel' data-slide='next'>");
      out.println("<span class='glyphicon glyphicon-chevron-right'></span>");
     out.println(" <span class='sr-only'>Next</span>");
   out.println(" </a> ");
								out.println("</div>");
								

				}
			 
			}

			 
		
		
	out.println("</section>");
		
 out.println("</div><!--features_items-->");
	   out.println("</div>");
	   out.println("</div>");
	   out.println("</div>");
	   out.println("</section>");
	   
	   out.println("<footer id='footer'><!--Footer-->");
	   out.println("<div class='footer-bottom'>");
	   out.println("<div class='container'>");
	   out.println("<div class='row'>");
	   out.println("<p class='pull-left'>Copyright © 2017 Smart Portables Inc. All rights reserved.</p>");
	   out.println("<p class='pull-right'>Designed by <span><a target='_blank' href='https://www.linkedin.com/in/abhishek-vijhani'>Abhishek Vijhani</a></span></p>");
	   out.println("</div>");
	   out.println("</div>");
	   out.println("</div>");
	   out.println("</footer><!--/Footer-->");
	   out.println("<script src='js/jquery.js'></script>");
	   out.println("<script src='js/bootstrap.min.js'></script>");
	   out.println("</body>");
	   out.println("</html>");
	   
}
}