import java.io.Serializable;

public class User {

	String userName;
	String passWord;
	String role;
	
	public  User(String userName,String passWord,String role)
{
	
	this.userName = userName;
	this.passWord = passWord;
	this.role = role;
	
	
}
	
	public String getUserName() {
		return userName;
	}

	public String getPassWord() {
		return passWord;
	}

	public String getRole() {
		return role;
	}

	
}
