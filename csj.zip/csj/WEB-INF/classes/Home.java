import java.util.HashMap;
import java.util.Map;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.text.*;
import java.util.*;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;




@WebServlet("/Home")

public class Home extends HttpServlet {

 
		
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
	  //session.setAttribute("role","nouser");
	  MySqlDataStoreUtilities.deletetable();
	  MySqlDataStoreUtilities.createtable();
	  
	response.setContentType("text/html");
	PrintWriter pw = response.getWriter();
	response.sendRedirect("index.html");
	//response.sendRedirect("DealMatches");
	}
	}

